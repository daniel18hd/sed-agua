import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense, useEffect, useState } from "react";

export const Route = createFileRoute("/")({ component: Index });

const Tablero = lazy(() => import("@/acompana/Tablero"));
const STYLE = "https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json";

// El tablero usa el mapa del navegador: se monta solo en el cliente.
function Index() {
  const [cliente, setCliente] = useState(false);
  useEffect(() => setCliente(true), []);
  return (
    <div style={{ position: "fixed", inset: 0, background: "#06080c" }}>
      {cliente && (
        <Suspense fallback={null}>
          <Tablero styleUrl={STYLE} />
        </Suspense>
      )}
    </div>
  );
}
