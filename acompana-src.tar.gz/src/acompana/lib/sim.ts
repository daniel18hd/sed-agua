// Motor de simulación del monitoreo: avance de cada grupo sobre su trayecto, posición de vehículos e integrantes,
// última señal de cada persona, escenarios y alertas. Funciones puras sobre un estado mutable por grupo.
import type { Grupo, LngLat, EscenarioId, Persona } from "./datos";

export const SIM_X = 30;            // segundos simulados por segundo real
export const HORA_BASE = 7 * 3600 + 42 * 60; // 07:42:00 al iniciar el demo

// ------------------------------------------------------------------ geometría
export const R = 6371;
export function km(a: LngLat, b: LngLat): number {
  const dLat = ((b[1] - a[1]) * Math.PI) / 180, dLon = ((b[0] - a[0]) * Math.PI) / 180;
  const s = Math.sin(dLat / 2) ** 2 + Math.cos((a[1] * Math.PI) / 180) * Math.cos((b[1] * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}
export interface Trayecto { path: LngLat[]; cum: number[]; total: number }
export function trayecto(path: LngLat[]): Trayecto {
  const cum = [0];
  for (let i = 1; i < path.length; i++) cum.push(cum[i - 1] + km(path[i - 1], path[i]));
  return { path, cum, total: cum[cum.length - 1] };
}
export function sobre(t: Trayecto, d: number): LngLat {
  const x = Math.max(0, Math.min(t.total, d));
  let lo = 0, hi = t.cum.length - 1;
  while (hi - lo > 1) { const m = (lo + hi) >> 1; if (t.cum[m] < x) lo = m; else hi = m; }
  const f = (x - t.cum[lo]) / (t.cum[hi] - t.cum[lo] || 1);
  return [t.path[lo][0] + (t.path[hi][0] - t.path[lo][0]) * f, t.path[lo][1] + (t.path[hi][1] - t.path[lo][1]) * f];
}
/** Dirección (unitaria, en grados aprox.) del trayecto en el km d, y su perpendicular. */
function direccion(t: Trayecto, d: number): { dir: LngLat; perp: LngLat } {
  const a = sobre(t, d - 0.3), b = sobre(t, d + 0.3);
  const k = Math.cos((a[1] * Math.PI) / 180);
  let dx = (b[0] - a[0]) * k, dy = b[1] - a[1];
  const n = Math.hypot(dx, dy) || 1; dx /= n; dy /= n;
  return { dir: [dx / k, dy], perp: [-dy / k, dx] };
}
export function kmEnTrayecto(t: Trayecto, p: LngLat): number {
  let best = 0, bd = Infinity;
  for (let i = 0; i < t.path.length; i += Math.max(1, Math.floor(t.path.length / 1500))) { const d = km(t.path[i], p); if (d < bd) { bd = d; best = i; } }
  return t.cum[best];
}
export function distATrayecto(t: Trayecto, p: LngLat, cerca?: number): number {
  let bd = Infinity;
  const i0 = cerca == null ? 0 : Math.max(0, t.cum.findIndex((c) => c > cerca - 15)), i1 = cerca == null ? t.path.length : t.cum.findIndex((c) => c > cerca + 15);
  for (let i = i0; i < (i1 < 0 ? t.path.length : i1); i++) bd = Math.min(bd, km(t.path[i], p));
  return bd;
}
const hash = (s: string) => { let h = 2166136261; for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619); return ((h >>> 0) % 10000) / 10000; };
const mover = (p: LngLat, v: LngLat, kmD: number): LngLat => [p[0] + v[0] * kmD / 111, p[1] + v[1] * kmD / 111];

// ------------------------------------------------------------------ estado
export type Nivel = "info" | "ok" | "aviso" | "alerta";
export interface Evento { t: number; nivel: Nivel; texto: string }
export type Incidente =
  | { tipo: "separado"; persona: string; desde: LngLat; dir: LngLat; t0: number; alertado: boolean }
  | { tipo: "senal"; personas: string[]; pos: Record<string, LngLat>; t0: number; alertado: boolean }
  | { tipo: "fuera"; ids: string[]; vehiculo: number; desde: LngLat; dir: LngLat; t0: number; alertado: boolean };
export interface EstadoGrupo {
  g: Grupo; tr: Trayecto; km: number; km0: number;
  llegando: boolean; velLlegada: number; enDestino: boolean; incidente: Incidente | null; atendida: boolean;
  eventos: Evento[]; pasos: { nombre: string; km: number; hecho: boolean }[];
}
export type Estatus = "En ruta" | "Detenido" | "Alerta" | "En destino";

export function iniciar(g: Grupo, path: LngLat[]): EstadoGrupo {
  const tr = trayecto(path);
  const km0 = tr.total * g.progreso0;
  const pasos = g.via.map((v) => ({ nombre: v.nombre, km: kmEnTrayecto(tr, [v.lon, v.lat]), hecho: false }));
  const vel = g.velKmh / 3600;
  const eventos: Evento[] = [
    { t: -km0 / vel - 1800, nivel: "info", texto: `Activación registrada · ${g.personas.length} personas${g.vehiculos ? ` · ${g.vehiculos} ${g.vehiculos === 1 ? "vehículo" : "vehículos"}` : " · a pie"} · ubicación compartida con consentimiento` },
    { t: -km0 / vel, nivel: "info", texto: `Salida de ${g.origen.nombre}` },
  ];
  for (const p of pasos) if (p.km < km0) { p.hecho = true; eventos.push({ t: -(km0 - p.km) / vel, nivel: "info", texto: `Paso por ${p.nombre}` }); }
  return { g, tr, km: km0, km0, llegando: false, velLlegada: 0, enDestino: false, incidente: null, atendida: false, eventos, pasos };
}

const vehiculoKm = (e: EstadoGrupo, v: number) => e.km - Math.max(0, v - 1) * 0.9;

/** Posición de cada integrante (y si está "congelado" por falta de señal). */
export function posPersona(e: EstadoGrupo, p: Persona, t: number): LngLat {
  const inc = e.incidente;
  if (inc?.tipo === "senal" && inc.pos[p.id]) return inc.pos[p.id];
  if (inc?.tipo === "separado" && inc.persona === p.id) return mover(inc.desde, inc.dir, Math.min(2.6, ((t - inc.t0) / 3600) * 14));
  const h = hash(p.id), h2 = hash(p.id + "y");
  if (inc?.tipo === "fuera" && inc.ids.includes(p.id)) {
    const c = mover(inc.desde, inc.dir, Math.min(2.1, ((t - inc.t0) / 120) * 2.1));
    return [c[0] + (h - 0.5) * 0.0006, c[1] + (h2 - 0.5) * 0.0006];
  }
  if (!e.g.vehiculos) {
    // a pie: el grupo se estira ~2.5 km sobre el camino
    const base = sobre(e.tr, e.km - h * 2.5);
    const w = Math.sin(t / 240 + h * 20) * 0.00025;
    return [base[0] + (h2 - 0.5) * 0.0016 + w, base[1] + (hash(p.id + "z") - 0.5) * 0.0016];
  }
  const c = sobre(e.tr, vehiculoKm(e, p.vehiculo));
  return [c[0] + (h - 0.5) * 0.00045, c[1] + (h2 - 0.5) * 0.00045];
}
export function posVehiculo(e: EstadoGrupo, v: number, t: number): LngLat {
  const inc = e.incidente;
  if (inc?.tipo === "fuera" && inc.vehiculo === v) return mover(inc.desde, inc.dir, Math.min(2.1, ((t - inc.t0) / 120) * 2.1));
  return sobre(e.tr, vehiculoKm(e, v));
}
export function centro(e: EstadoGrupo): LngLat { return sobre(e.tr, e.g.vehiculos ? e.km - (e.g.vehiculos - 1) * 0.45 : e.km - 1.25); }

/** Segundos desde la última señal de la persona. */
export function ultimaSenal(e: EstadoGrupo, p: Persona, t: number): number {
  const inc = e.incidente;
  if (inc?.tipo === "senal" && inc.personas.includes(p.id)) return Math.max(0, t - inc.t0) + hash(p.id) * 40;
  return Math.floor((t + hash(p.id) * 60) % 60);
}

export function estatus(e: EstadoGrupo): Estatus {
  if (e.enDestino) return "En destino";
  if (e.incidente?.alertado && !e.atendida) return "Alerta";
  if (e.incidente?.tipo === "fuera") return "Detenido";
  return "En ruta";
}

export const hhmm = (t: number, seg = false) => {
  const s = ((Math.floor(HORA_BASE + t) % 86400) + 86400) % 86400;
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}${seg ? `:${String(x).padStart(2, "0")}` : ""}`;
};
/** Hora con día relativo para la línea de tiempo (grupos que llevan más de un día en camino). */
export const hhmmDia = (t: number) => {
  const d = Math.floor((HORA_BASE + t) / 86400);
  return d === 0 ? hhmm(t) : d === -1 ? `ayer ${hhmm(t)}` : `${d < 0 ? `hace ${-d} días` : `+${d} d`} ${hhmm(t)}`;
};
const kmTxt = (d: number) => (d < 1 ? `${Math.round(d * 1000)} m` : `${d.toFixed(1)} km`);

/** Avanza la simulación dt segundos simulados. Devuelve las alertas nuevas. */
export function avanzar(e: EstadoGrupo, t: number, dt: number): { titulo: string; texto: string; pos: LngLat }[] {
  const nuevas: { titulo: string; texto: string; pos: LngLat }[] = [];
  const g = e.g;
  if (!e.enDestino) {
    const vel = e.llegando ? Math.max(g.velKmh / 3600, e.velLlegada) : g.velKmh / 3600;
    e.km = Math.min(e.tr.total, e.km + vel * dt);
    for (const p of e.pasos) if (!p.hecho && e.km >= p.km) { p.hecho = true; e.eventos.push({ t, nivel: "info", texto: `Paso por ${p.nombre}` }); }
    if (e.km >= e.tr.total - 0.01) {
      e.enDestino = true; e.llegando = false;
      const fuera = e.incidente && !e.atendida ? 1 : 0;
      const n = g.personas.length;
      e.eventos.push({ t, nivel: "ok", texto: `Llegada a ${g.destino.nombre} · ${n - fuera}/${n} integrantes confirmados con señal` });
      nuevas.push({ titulo: `${g.nombre} llegó a destino`, texto: `${n - fuera} de ${n} integrantes confirmados en ${g.destino.nombre}.`, pos: [g.destino.lon, g.destino.lat] });
    }
  }
  const inc = e.incidente;
  if (inc && !inc.alertado) {
    if (inc.tipo === "separado") {
      const p = g.personas.find((x) => x.id === inc.persona)!;
      const d = km(posPersona(e, p, t), centro(e));
      if (d > 0.5) {
        inc.alertado = true;
        const texto = `${p.alias} (${p.id}) está a ${kmTxt(d)} de su grupo y la distancia aumenta.`;
        e.eventos.push({ t, nivel: "alerta", texto: `Integrante separado · ${p.alias} (${p.id}) a ${kmTxt(d)} del grupo` });
        nuevas.push({ titulo: `${g.nombre} · integrante separado`, texto, pos: posPersona(e, p, t) });
      }
    } else if (inc.tipo === "senal") {
      if (t - inc.t0 > 180) {
        inc.alertado = true;
        const v = g.personas.find((x) => x.id === inc.personas[0])!.vehiculo;
        const texto = `${inc.personas.length} integrantes${v ? ` del vehículo ${v}` : ""} sin señal desde las ${hhmm(inc.t0)}. Se conserva su última ubicación.`;
        e.eventos.push({ t, nivel: "alerta", texto: `Pérdida de señal · ${inc.personas.length} integrantes${v ? ` (vehículo ${v})` : ""} sin reportar desde ${hhmm(inc.t0)}` });
        nuevas.push({ titulo: `${g.nombre} · pérdida de señal`, texto, pos: Object.values(inc.pos)[0] });
      }
    } else if (inc.tipo === "fuera") {
      if (t - inc.t0 > 150) {
        inc.alertado = true;
        const pos = posVehiculo(e, inc.vehiculo, t);
        const d = distATrayecto(e.tr, pos, e.km);
        const quien = g.vehiculos ? `Vehículo ${inc.vehiculo}` : `Subgrupo de ${inc.ids.length} personas`;
        const texto = `${quien} detenido a ${kmTxt(d)} de la ruta desde las ${hhmm(inc.t0)}. ${inc.ids.length} personas a bordo.`;
        e.eventos.push({ t, nivel: "alerta", texto: `Detenido fuera de ruta · ${quien} a ${kmTxt(d)} de la ruta` });
        nuevas.push({ titulo: `${g.nombre} · detenido fuera de ruta`, texto, pos });
      }
    }
  }
  return nuevas;
}

/** Aplica un escenario de demo a un grupo. */
export function escenario(e: EstadoGrupo, id: EscenarioId, t: number) {
  const g = e.g;
  if (id === "normal") {
    if (e.incidente || e.enDestino || e.llegando) e.eventos.push({ t, nivel: "ok", texto: "Operación normal · todos los integrantes reportando" });
    e.incidente = null; e.atendida = false; e.llegando = false;
    if (e.enDestino) { e.enDestino = false; e.km = e.km0; for (const p of e.pasos) p.hecho = p.km < e.km; }
    return;
  }
  if (e.enDestino) { e.enDestino = false; e.km = e.km0; for (const p of e.pasos) p.hecho = p.km < e.km; }
  e.incidente = null; e.atendida = false; e.llegando = false;
  const { perp } = direccion(e.tr, e.km);
  if (id === "separado") {
    const p = g.personas[Math.floor(g.personas.length * 0.37)];
    e.incidente = { tipo: "separado", persona: p.id, desde: posPersona(e, p, t), dir: perp, t0: t, alertado: false };
    e.eventos.push({ t, nivel: "aviso", texto: `${p.alias} (${p.id}) se aleja del grupo` });
  } else if (id === "senal") {
    const v = g.vehiculos ? g.vehiculos : 0;
    const ps = (v ? g.personas.filter((p) => p.vehiculo === v) : g.personas.filter((_, i) => i % 15 === 4)).slice(0, v ? 7 : 12);
    e.incidente = { tipo: "senal", personas: ps.map((p) => p.id), pos: Object.fromEntries(ps.map((p) => [p.id, posPersona(e, p, t)])), t0: t, alertado: false };
    e.eventos.push({ t, nivel: "aviso", texto: `${ps.length} integrantes dejan de reportar ubicación` });
  } else if (id === "fuera") {
    const v = g.vehiculos ? g.vehiculos : 0;
    const ids = (v ? g.personas.filter((p) => p.vehiculo === v) : g.personas.filter((_, i) => i % 9 === 0)).map((p) => p.id);
    const desde = v ? posVehiculo(e, v, t) : sobre(e.tr, e.km - 1.2);
    e.incidente = { tipo: "fuera", ids, vehiculo: v, desde, dir: [-perp[0], -perp[1]], t0: t, alertado: false };
    e.eventos.push({ t, nivel: "aviso", texto: `${v ? `Vehículo ${v}` : `Subgrupo de ${ids.length} personas`} sale de la ruta prevista` });
  } else if (id === "llegada") {
    e.llegando = true; e.velLlegada = (e.tr.total - e.km) / 200;
    e.eventos.push({ t, nivel: "info", texto: `Último tramo hacia ${g.destino.nombre}` });
  }
}

export function atender(e: EstadoGrupo, t: number) {
  if (!e.incidente?.alertado || e.atendida) return;
  e.atendida = true;
  e.eventos.push({ t, nivel: "ok", texto: "Alerta en atención · enlace de seguimiento contactó al grupo" });
}
