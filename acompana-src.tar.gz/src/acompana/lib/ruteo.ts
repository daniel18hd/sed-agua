// Trazo de cada trayecto sobre la red carretera (servicio interno /api/ruta). Si no hay servicio, se usan los puntos de paso.
import type { LngLat } from "./datos";

export function decode6(str: string): LngLat[] {
  let i = 0, lat = 0, lon = 0;
  const out: LngLat[] = [];
  while (i < str.length) {
    for (const k of [0, 1]) {
      let b, shift = 0, res = 0;
      do { b = str.charCodeAt(i++) - 63; res |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
      const d = res & 1 ? ~(res >> 1) : res >> 1;
      if (k === 0) lat += d; else lon += d;
    }
    out.push([lon / 1e6, lat / 1e6]);
  }
  return out;
}

/** Reduce puntos muy cercanos para que la animación sea ligera. */
export function simplificar(c: LngLat[], minKm = 0.08): LngLat[] {
  if (c.length < 3) return c;
  const out: LngLat[] = [c[0]];
  for (let i = 1; i < c.length - 1; i++) {
    const a = out[out.length - 1], b = c[i];
    if (Math.hypot((b[0] - a[0]) * Math.cos((b[1] * Math.PI) / 180), b[1] - a[1]) * 111 >= minKm) out.push(b);
  }
  out.push(c[c.length - 1]);
  return out;
}
