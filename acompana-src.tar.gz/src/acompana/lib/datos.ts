// Datos SIMULADOS para el demo. Grupos, personas y trayectos son ficticios; los nombres son parciales a propósito.
// La ubicación se comparte con consentimiento desde la app de registro (fuera de este tablero).
export type LngLat = [number, number];
export type Vista = "activaciones" | "migracion";
export interface Lugar { nombre: string; lat: number; lon: number }
export interface Punto extends Lugar { tipo: "albergue" | "atencion" | "medico" }
export interface Persona { id: string; alias: string; vehiculo: number }
export interface Grupo {
  id: string; vista: Vista; nombre: string; tipo: string;
  origen: Lugar; destino: Lugar; via: Lugar[];
  vehiculos: number;            // 0 = a pie
  personas: Persona[];
  color: [number, number, number];
  velKmh: number; progreso0: number; // avance inicial (0–1)
  salida: string;               // hora de salida (texto)
}

const L = (nombre: string, lat: number, lon: number): Lugar => ({ nombre, lat, lon });
const CDMX = L("Ciudad de México", 19.4326, -99.1332);

function rng(seed: number) {
  let a = seed >>> 0;
  return () => { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
const NOMBRES = ["María", "Rosa", "Guadalupe", "Juana", "Ana", "Patricia", "Leticia", "Martha", "Elena", "Carmen", "Silvia", "Verónica", "Teresa", "Gloria", "Alicia", "Norma", "Julia", "Irma", "José", "Juan", "Luis", "Carlos", "Miguel", "Jorge", "Pedro", "Raúl", "Sofía", "Lucía", "Adriana", "Beatriz"];
const INICIAL = "ABCDEFGHJLMNOPRSTVZ";

function personas(prefijo: string, n: number, vehiculos: number, seed: number, soloIniciales = false): Persona[] {
  const r = rng(seed);
  return Array.from({ length: n }, (_, i) => {
    const nom = NOMBRES[Math.floor(r() * NOMBRES.length)];
    const ini = INICIAL[Math.floor(r() * INICIAL.length)];
    const alias = soloIniciales ? `${nom[0]}. ${ini}.` : `${nom} ${ini}.`;
    return { id: `${prefijo}-${String(i + 1).padStart(3, "0")}`, alias, vehiculo: vehiculos ? (i % vehiculos) + 1 : 0 };
  });
}

export const GRUPOS: Grupo[] = [
  // ---------------- Activaciones: colectivos de búsqueda que viajan entre estados
  { id: "BN", vista: "activaciones", nombre: "Brigada Norte", tipo: "Colectivo de búsqueda", origen: CDMX, destino: L("Reynosa, Tamps.", 26.0508, -98.2979),
    via: [L("Querétaro", 20.5888, -100.3899), L("San Luis Potosí", 22.1565, -100.9855), L("Matehuala", 23.6494, -100.6439), L("Monterrey", 25.6866, -100.3161)],
    vehiculos: 2, personas: personas("BN", 74, 2, 11), color: [45, 212, 191], velKmh: 88, progreso0: 0.34, salida: "04:30" },
  { id: "BP", vista: "activaciones", nombre: "Brigada Pacífico", tipo: "Colectivo de búsqueda", origen: L("Guadalajara", 20.6597, -103.3496), destino: L("Hermosillo, Son.", 29.0729, -110.9559),
    via: [L("Tepic", 21.5042, -104.8946), L("Mazatlán", 23.2494, -106.4111), L("Culiacán", 24.8091, -107.394), L("Los Mochis", 25.7905, -108.986), L("Ciudad Obregón", 27.4828, -109.9304)],
    vehiculos: 1, personas: personas("BP", 41, 1, 22), color: [129, 140, 248], velKmh: 84, progreso0: 0.52, salida: "02:00" },
  { id: "BS", vista: "activaciones", nombre: "Brigada Sur", tipo: "Colectivo de búsqueda", origen: CDMX, destino: L("Chilpancingo, Gro.", 17.5506, -99.5058),
    via: [L("Cuernavaca", 18.9242, -99.2216), L("Iguala", 18.3448, -99.5399)],
    vehiculos: 3, personas: personas("BS", 118, 3, 33), color: [251, 146, 60], velKmh: 78, progreso0: 0.42, salida: "06:15" },
  { id: "BG", vista: "activaciones", nombre: "Brigada Golfo", tipo: "Colectivo de búsqueda", origen: L("Puebla", 19.0414, -98.2063), destino: L("Coatzacoalcos, Ver.", 18.1345, -94.459),
    via: [L("Córdoba", 18.8842, -96.9256), L("Cosamaloapan", 18.367, -95.798), L("Acayucan", 17.949, -94.914)],
    vehiculos: 2, personas: personas("BG", 67, 2, 44), color: [244, 114, 182], velKmh: 82, progreso0: 0.22, salida: "05:40" },
  // ---------------- Migración: acompañamiento humanitario de grupos en tránsito
  { id: "M21", vista: "migracion", nombre: "Grupo M-21", tipo: "Grupo en tránsito · a pie", origen: L("Tapachula, Chis.", 14.9056, -92.2633), destino: L("Arriaga, Chis.", 16.2359, -93.8996),
    via: [L("Huixtla", 15.1389, -92.4664), L("Escuintla", 15.317, -92.659), L("Pijijiapan", 15.686, -93.211)],
    vehiculos: 0, personas: personas("M21", 180, 0, 55, true), color: [250, 204, 21], velKmh: 4.2, progreso0: 0.46, salida: "03:00" },
  { id: "M08", vista: "migracion", nombre: "Grupo M-08", tipo: "Grupo en tránsito · autobús", origen: L("Coatzacoalcos, Ver.", 18.1345, -94.459), destino: CDMX,
    via: [L("Acayucan", 17.949, -94.914), L("Córdoba", 18.8842, -96.9256), L("Puebla", 19.0414, -98.2063)],
    vehiculos: 2, personas: personas("M08", 96, 2, 66, true), color: [56, 189, 248], velKmh: 80, progreso0: 0.3, salida: "05:00" },
  { id: "M15", vista: "migracion", nombre: "Grupo M-15", tipo: "Grupo en tránsito · autobús", origen: CDMX, destino: L("Piedras Negras, Coah.", 28.7, -100.5236),
    via: [L("Querétaro", 20.5888, -100.3899), L("San Luis Potosí", 22.1565, -100.9855), L("Saltillo", 25.4232, -101.0053), L("Monclova", 26.9103, -101.4222)],
    vehiculos: 1, personas: personas("M15", 54, 1, 77, true), color: [192, 132, 252], velKmh: 86, progreso0: 0.58, salida: "23:30" },
];

// Albergues y puntos de atención (genéricos, para el demo)
export const PUNTOS: Punto[] = [
  { tipo: "albergue", nombre: "Albergue · Tapachula", lat: 14.912, lon: -92.27 },
  { tipo: "atencion", nombre: "Punto de atención · Huixtla", lat: 15.142, lon: -92.47 },
  { tipo: "medico", nombre: "Punto médico · Escuintla", lat: 15.32, lon: -92.66 },
  { tipo: "medico", nombre: "Punto médico · Pijijiapan", lat: 15.689, lon: -93.214 },
  { tipo: "albergue", nombre: "Albergue · Arriaga", lat: 16.238, lon: -93.902 },
  { tipo: "albergue", nombre: "Albergue · Ixtepec", lat: 16.563, lon: -95.1 },
  { tipo: "albergue", nombre: "Albergue · Coatzacoalcos", lat: 18.14, lon: -94.45 },
  { tipo: "atencion", nombre: "Punto de atención · Acayucan", lat: 17.95, lon: -94.91 },
  { tipo: "albergue", nombre: "Albergue · Córdoba", lat: 18.89, lon: -96.93 },
  { tipo: "albergue", nombre: "Albergue · Puebla", lat: 19.045, lon: -98.2 },
  { tipo: "albergue", nombre: "Albergue · Ciudad de México", lat: 19.44, lon: -99.14 },
  { tipo: "medico", nombre: "Punto médico · Querétaro", lat: 20.59, lon: -100.39 },
  { tipo: "albergue", nombre: "Albergue · San Luis Potosí", lat: 22.16, lon: -100.98 },
  { tipo: "albergue", nombre: "Albergue · Saltillo", lat: 25.425, lon: -101.0 },
  { tipo: "atencion", nombre: "Punto de atención · Monclova", lat: 26.912, lon: -101.42 },
  { tipo: "albergue", nombre: "Albergue · Piedras Negras", lat: 28.705, lon: -100.52 },
];

export const ESCENARIOS = [
  { id: "normal", titulo: "Traslado normal", desc: "Todo en orden" },
  { id: "separado", titulo: "Integrante separado", desc: "Se aleja del grupo" },
  { id: "senal", titulo: "Pérdida de señal", desc: "Varios integrantes" },
  { id: "fuera", titulo: "Detenido fuera de ruta", desc: "Un vehículo se desvía" },
  { id: "llegada", titulo: "Llegada al destino", desc: "Conteo final" },
] as const;
export type EscenarioId = (typeof ESCENARIOS)[number]["id"];
