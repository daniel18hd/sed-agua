// Mapa del tablero: globo + capas animadas (trayectos, vehículos, integrantes, alertas, albergues). Un solo bucle rAF.
import maplibregl, { type Map as MLMap, type StyleSpecification, type LngLatBoundsLike } from "maplibre-gl";
import type { LngLat, Punto } from "@/acompana/lib/datos";
import { type EstadoGrupo, posPersona, posVehiculo, centro, ultimaSenal, sobre, estatus } from "@/acompana/lib/sim";

type RGB = [number, number, number];
const ROJO: RGB = [239, 68, 68], AMBAR: RGB = [245, 158, 11], GRIS: RGB = [100, 116, 139], VERDE: RGB = [74, 222, 128];
const EASE = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
const PAD = { top: 110, bottom: 90, left: 440, right: 470 };

async function loadStyle(url: string): Promise<StyleSpecification | string> {
  try {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 4000);
    const r = await fetch(url, { signal: ctl.signal });
    clearTimeout(t);
    if (!r.ok) throw new Error(String(r.status));
    return (await r.json()) as StyleSpecification;
  } catch {
    return { version: 8, sources: {}, layers: [{ id: "bg", type: "background", paint: { "background-color": "#07090d" } }] };
  }
}
function bbox(pts: LngLat[], pad = 0): [LngLat, LngLat] {
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (const [x, y] of pts) { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); }
  return [[x0 - pad, y0 - pad], [x1 + pad, y1 + pad]];
}

export class Monitor {
  map!: MLMap;
  ready = false;
  private overlay: any = null;
  private D: any = null;
  private raf = 0;
  private destroyed = false;
  private estados: EstadoGrupo[] = [];
  private puntos: Punto[] = [];
  private sel: string | null = null;
  private seguir = false;
  private ultSeguir = 0;
  private encuadre: (() => LngLat[]) | null = null;
  private recorridos = new Map<string, { km: number; path: LngLat[] }>();
  onPick: (id: string) => void = () => {};

  constructor(private el: HTMLElement, private styleUrl: string, private tiempo: () => number) {}

  async start() {
    const style = await loadStyle(this.styleUrl);
    if (this.destroyed) return;
    const m = new maplibregl.Map({ container: this.el, style, center: [-102, 23], zoom: 1.6, attributionControl: { compact: true }, pixelRatio: Math.min(devicePixelRatio || 1, 2), fadeDuration: 0 } as any);
    this.map = m;
    await new Promise<void>((res) => { let d = false; const ok = () => { if (!d) { d = true; res(); } }; m.once("style.load", ok); m.once("load", ok); if (m.isStyleLoaded()) ok(); });
    m.setProjection({ type: "globe" });
    m.setPadding(PAD as any);
    m.setSky({ "sky-color": "#06080c", "horizon-color": "#0b2a2a", "fog-color": "#06080c", "sky-horizon-blend": 0.6, "horizon-fog-blend": 0.4, "fog-ground-blend": 0.85, "atmosphere-blend": ["interpolate", ["linear"], ["zoom"], 0, 1, 6, 0.5, 9, 0] } as any);
    for (const l of m.getStyle().layers ?? []) if (l.type === "background") m.setPaintProperty(l.id, "background-color", "#06080c");
    m.on("dragstart", () => { this.seguir = false; this.encuadre = null; });
    const [{ MapboxOverlay }, L] = await Promise.all([import("@deck.gl/mapbox"), import("@deck.gl/layers")]);
    this.D = { Scatter: L.ScatterplotLayer, Line: L.LineLayer, Path: L.PathLayer, Text: L.TextLayer };
    this.overlay = new MapboxOverlay({ interleaved: true, layers: [], onClick: (info: any) => { const id = info?.object?.grupo; if (id) this.onPick(id); }, getCursor: ({ isHovering }: any) => (isHovering ? "pointer" : "grab") } as any);
    m.addControl(this.overlay);
    this.ready = true;
    this.loop();
  }

  escena(estados: EstadoGrupo[], puntos: Punto[]) { this.estados = estados; this.puntos = puntos; this.recorridos.clear(); }
  seleccionar(id: string | null) { this.sel = id; }
  setSeguir(v: boolean) { this.seguir = v; this.ultSeguir = 0; if (v) this.encuadre = null; }
  /** Mantiene en cuadro un conjunto de puntos que cambia (p. ej. el grupo y la persona separada). */
  setEncuadre(f: (() => LngLat[]) | null) { this.encuadre = f; this.ultSeguir = 0; if (f) this.seguir = false; }

  // ------------------------------------------------------------ cámara
  general(ms = 2600) {
    this.encuadre = null; this.seguir = false;
    const pts = this.estados.flatMap((e) => [[e.g.origen.lon, e.g.origen.lat] as LngLat, [e.g.destino.lon, e.g.destino.lat] as LngLat, ...e.g.via.map((v) => [v.lon, v.lat] as LngLat)]);
    if (!pts.length) return;
    this.map.fitBounds(bbox(pts, 0.6) as LngLatBoundsLike, { padding: 40, duration: ms, easing: EASE, pitch: 0, bearing: 0, maxZoom: 7 } as any);
  }
  grupo(e: EstadoGrupo, ms = 2200) {
    this.encuadre = null; this.seguir = false;
    this.map.fitBounds(bbox(e.tr.path, 0.25) as LngLatBoundsLike, { padding: 40, duration: ms, easing: EASE, pitch: 0, bearing: 0, maxZoom: 9 } as any);
  }
  irA(p: LngLat, zoom = 13, ms = 2400) {
    this.map.flyTo({ center: p, zoom, pitch: 35, bearing: 0, duration: ms, easing: EASE } as any);
  }

  // ------------------------------------------------------------ dibujo
  private recorrido(e: EstadoGrupo): LngLat[] {
    const c = this.recorridos.get(e.g.id);
    if (c && Math.abs(c.km - e.km) < 0.15) return c.path;
    const out: LngLat[] = [];
    for (let i = 0; i < e.tr.path.length && e.tr.cum[i] < e.km; i++) out.push(e.tr.path[i]);
    out.push(sobre(e.tr, e.km));
    this.recorridos.set(e.g.id, { km: e.km, path: out });
    return out;
  }

  private loop = () => {
    if (this.destroyed) return;
    this.raf = requestAnimationFrame(this.loop);
    if (!this.ready || !this.overlay) return;
    const t = this.tiempo(), now = performance.now(), D = this.D;
    const pulso = (now % 1600) / 1600;
    const zoom = this.map.getZoom();
    const layers: any[] = [];
    const sel = this.sel;
    const dim = (id: string) => (sel && sel !== id ? 0.35 : 1);

    // albergues y puntos de atención
    if (this.puntos.length) {
      layers.push(new D.Scatter({ id: "puntos", data: this.puntos, getPosition: (p: Punto) => [p.lon, p.lat], radiusUnits: "pixels", getRadius: 6, filled: true, stroked: true,
        getFillColor: (p: Punto) => (p.tipo === "medico" ? [56, 189, 248, 70] : [...VERDE, 60]), getLineColor: (p: Punto) => (p.tipo === "medico" ? [56, 189, 248, 230] : [...VERDE, 230]), lineWidthUnits: "pixels", getLineWidth: 1.5 }));
      if (zoom > 5.2) layers.push(new D.Text({ id: "puntos-t", data: this.puntos, getPosition: (p: Punto) => [p.lon, p.lat], getText: (p: Punto) => p.nombre, getSize: 11, getColor: [187, 247, 208, 230], getPixelOffset: [0, 14],
        fontFamily: "Inter Variable, system-ui, sans-serif", fontWeight: 600, characterSet: "auto", outlineWidth: 3, outlineColor: [6, 8, 12, 255], fontSettings: { sdf: true } }));
    }

    const rutas = this.estados.map((e) => ({ e, a: dim(e.g.id) }));
    layers.push(new D.Path({ id: "pendiente", data: rutas, getPath: (r: any) => r.e.tr.path, getColor: (r: any) => [...r.e.g.color, 70 * r.a], widthUnits: "pixels", getWidth: 2, jointRounded: true, capRounded: true, pickable: true, updateTriggers: { getColor: [sel] } }));
    layers.push(new D.Path({ id: "recorrido", data: rutas.map((r) => ({ ...r, grupo: r.e.g.id, path: this.recorrido(r.e) })), getPath: (r: any) => r.path, getColor: (r: any) => [...r.e.g.color, 235 * r.a], widthUnits: "pixels", getWidth: 4, jointRounded: true, capRounded: true, pickable: true }));
    // origen y destino
    const od = this.estados.flatMap((e) => [{ p: [e.g.origen.lon, e.g.origen.lat], c: e.g.color, o: true, a: dim(e.g.id), n: e.g.origen.nombre, grupo: e.g.id }, { p: [e.g.destino.lon, e.g.destino.lat], c: e.g.color, o: false, a: dim(e.g.id), n: e.g.destino.nombre, grupo: e.g.id }]);
    layers.push(new D.Scatter({ id: "od", data: od, getPosition: (d: any) => d.p, radiusUnits: "pixels", getRadius: (d: any) => (d.o ? 5 : 7), filled: true, stroked: true,
      getFillColor: (d: any) => (d.o ? [6, 8, 12, 255 * d.a] : [...d.c, 255 * d.a]), getLineColor: (d: any) => [...d.c, 255 * d.a], lineWidthUnits: "pixels", getLineWidth: 2, pickable: true }));
    layers.push(new D.Text({ id: "od-t", data: od.filter((d) => !d.o || d.grupo === sel), getPosition: (d: any) => d.p, getText: (d: any) => (d.o ? `Origen · ${d.n}` : d.n), getSize: 11.5, getColor: (d: any) => [226, 232, 240, 235 * d.a],
      getPixelOffset: [0, -16], fontFamily: "Inter Variable, system-ui, sans-serif", fontWeight: 700, characterSet: "auto", outlineWidth: 3, outlineColor: [6, 8, 12, 255], fontSettings: { sdf: true } }));

    // integrantes
    const gente: any[] = [], vehs: any[] = [], anillos: any[] = [], lineas: any[] = [];
    for (const e of this.estados) {
      const a = dim(e.g.id), inc = e.incidente;
      const alerta = estatus(e) === "Alerta";
      for (const p of e.g.personas) {
        const pos = posPersona(e, p, t);
        const sin = ultimaSenal(e, p, t) > 120;
        const sep = inc?.tipo === "separado" && inc.persona === p.id;
        gente.push({ pos, c: sep ? ROJO : sin ? GRIS : e.g.color, a: sin ? 0.6 * a : a, r: sep ? 5 : 2.4, grupo: e.g.id });
      }
      for (let v = 1; v <= e.g.vehiculos; v++) {
        const fuera = inc?.tipo === "fuera" && inc.vehiculo === v;
        vehs.push({ pos: posVehiculo(e, v, t), v, c: fuera ? ROJO : e.g.color, a, grupo: e.g.id });
      }
      if (!e.g.vehiculos) vehs.push({ pos: centro(e), v: 0, c: e.g.color, a, grupo: e.g.id, pie: true });
      if (inc) {
        const c = inc.alertado && !e.atendida ? ROJO : e.atendida ? AMBAR : AMBAR;
        let pos: LngLat;
        if (inc.tipo === "separado") { pos = posPersona(e, e.g.personas.find((x) => x.id === inc.persona)!, t); lineas.push({ a: centro(e), b: pos, c: ROJO }); }
        else if (inc.tipo === "senal") pos = Object.values(inc.pos)[0];
        else { pos = posVehiculo(e, inc.vehiculo || 1, t); if (!e.g.vehiculos) pos = posPersona(e, e.g.personas.find((x) => x.id === inc.ids[0])!, t); lineas.push({ a: inc.desde, b: pos, c: ROJO }); }
        anillos.push({ pos, c, k: pulso, grupo: e.g.id }, { pos, c, k: (pulso + 0.5) % 1, grupo: e.g.id });
      } else if (alerta) { /* sin incidente activo */ }
      if (e.enDestino) anillos.push({ pos: [e.g.destino.lon, e.g.destino.lat], c: VERDE, k: pulso, grupo: e.g.id });
    }
    layers.push(new D.Line({ id: "lineas", data: lineas, getSourcePosition: (d: any) => d.a, getTargetPosition: (d: any) => d.b, getColor: (d: any) => [...d.c, 220], widthUnits: "pixels", getWidth: 2 }));
    layers.push(new D.Scatter({ id: "anillos", data: anillos, getPosition: (d: any) => d.pos, radiusUnits: "pixels", getRadius: (d: any) => 10 + d.k * 34, filled: false, stroked: true,
      getLineColor: (d: any) => [...d.c, 255 * (1 - d.k)], lineWidthUnits: "pixels", getLineWidth: 2, updateTriggers: { getRadius: now, getLineColor: now } }));
    layers.push(new D.Scatter({ id: "gente", data: gente, getPosition: (d: any) => d.pos, radiusUnits: "pixels", getRadius: (d: any) => d.r, getFillColor: (d: any) => [...d.c, 230 * d.a], pickable: true,
      updateTriggers: { getPosition: t } }));
    layers.push(new D.Scatter({ id: "vehiculos", data: vehs, getPosition: (d: any) => d.pos, radiusUnits: "pixels", getRadius: (d: any) => (d.pie ? 0 : 8), filled: true, stroked: true,
      getFillColor: (d: any) => [10, 12, 16, 255 * d.a], getLineColor: (d: any) => [...d.c, 255 * d.a], lineWidthUnits: "pixels", getLineWidth: 2.5, pickable: true, updateTriggers: { getPosition: t } }));
    layers.push(new D.Text({ id: "vehiculos-t", data: vehs.filter((d) => !d.pie), getPosition: (d: any) => d.pos, getText: (d: any) => String(d.v), getSize: 10, getColor: (d: any) => [255, 255, 255, 255 * d.a],
      fontFamily: "JetBrains Mono Variable, monospace", fontWeight: 700, characterSet: "auto", updateTriggers: { getPosition: t } }));
    this.overlay.setProps({ layers });

    // seguimiento de cámara
    if (this.encuadre && now - this.ultSeguir > 1000 && !this.map.isMoving()) {
      this.ultSeguir = now;
      const pts = this.encuadre();
      if (pts.length) this.map.fitBounds(bbox(pts, 0.006) as LngLatBoundsLike, { padding: 40, maxZoom: 14.5, duration: 950, easing: (x: number) => x, pitch: 30 } as any);
    } else if (this.seguir && sel && now - this.ultSeguir > 900 && !this.map.isMoving()) {
      this.ultSeguir = now;
      const e = this.estados.find((x) => x.g.id === sel);
      if (e) this.map.easeTo({ center: centro(e), duration: 850, easing: (x: number) => x } as any);
    }
  };

  destroy() { this.destroyed = true; cancelAnimationFrame(this.raf); try { this.map?.remove(); } catch {} }
}
