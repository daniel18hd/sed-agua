import "./acompana.css";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Monitor } from "./mapa";
import { decode6, simplificar } from "@/acompana/lib/ruteo";
import { GRUPOS, PUNTOS, ESCENARIOS, type Vista, type LngLat, type EscenarioId, type Grupo } from "@/acompana/lib/datos";
import { iniciar, avanzar, escenario, atender, estatus, hhmm, hhmmDia, km, centro, posPersona, posVehiculo, sobre, ultimaSenal, SIM_X, type EstadoGrupo, type Estatus } from "@/acompana/lib/sim";

const rgb = (c: [number, number, number], a = 1) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;
const n0 = (x: number) => Math.round(x).toLocaleString("es-MX");
const COLOR_ESTATUS: Record<Estatus, string> = { "En ruta": "text-[#5eead4] bg-[#14b8a6]/12 border-[#14b8a6]/30", Detenido: "text-[#fcd34d] bg-[#f59e0b]/12 border-[#f59e0b]/35", Alerta: "text-[#fca5a5] bg-[#ef4444]/15 border-[#ef4444]/45", "En destino": "text-[#86efac] bg-[#22c55e]/12 border-[#22c55e]/35" };
const NIVEL: Record<string, string> = { info: "bg-slate-500", ok: "bg-[#22c55e]", aviso: "bg-[#f59e0b]", alerta: "bg-[#ef4444]" };
const hace = (s: number) => (s < 60 ? `hace ${Math.max(1, Math.floor(s))} s` : `hace ${Math.floor(s / 60)} min`);

interface Aviso { id: number; grupo: string; titulo: string; texto: string; pos: LngLat; ok: boolean }

async function trazo(g: Grupo): Promise<LngLat[]> {
  const pts: LngLat[] = [[g.origen.lon, g.origen.lat], ...g.via.map((v) => [v.lon, v.lat] as LngLat), [g.destino.lon, g.destino.lat]];
  const c = pts.map((p) => p.map((v) => v.toFixed(4)).join(",")).join(";");
  try { const raw = localStorage.getItem(`acompana.ruta.${c}`); if (raw) return JSON.parse(raw); } catch {}
  const guardar = (x: LngLat[]) => { try { localStorage.setItem(`acompana.ruta.${c}`, JSON.stringify(x)); } catch {} return x; };
  const to = () => AbortSignal.timeout(15000);
  try {
    const body = { locations: pts.map(([lon, lat], i) => ({ lat, lon, type: i === 0 || i === pts.length - 1 ? "break" : "through", radius: 500 })), costing: "auto", directions_type: "none", units: "kilometers" };
    const j = await fetch("https://valhalla1.openstreetmap.de/route", { method: "POST", body: JSON.stringify(body), signal: to() }).then((r) => (r.ok ? r.json() : null));
    if (j?.trip) return guardar(simplificar((j.trip.legs as { shape: string }[]).flatMap((l, i) => { const d = decode6(l.shape); return i ? d.slice(1) : d; })));
  } catch {}
  try {
    const j = await fetch(`https://router.project-osrm.org/route/v1/driving/${pts.map((p) => p.join(",")).join(";")}?overview=full&geometries=geojson`, { signal: to() }).then((r) => (r.ok ? r.json() : null));
    if (j?.routes?.[0]) return guardar(simplificar(j.routes[0].geometry.coordinates));
  } catch {}
  return pts;
}

export default function Tablero({ styleUrl }: { styleUrl: string }) {
  const el = useRef<HTMLDivElement>(null);
  const mapa = useRef<Monitor | null>(null);
  const tRef = useRef(0);
  const estadosRef = useRef<Map<string, EstadoGrupo>>(new Map());
  const [listo, setListo] = useState(false);
  const [vista, setVista] = useState<Vista>("activaciones");
  const [sel, setSel] = useState<string | null>(null);
  const [tab, setTab] = useState<"personas" | "linea">("personas");
  const [seguir, setSeguir] = useState(false);
  const [avisos, setAvisos] = useState<Aviso[]>([]);
  const [ultimoEsc, setUltimoEsc] = useState<Record<string, EscenarioId>>({});
  const [, setTick] = useState(0);
  const avisoId = useRef(0);

  // mapa + trayectos
  useEffect(() => {
    if (!el.current) return;
    const m = new Monitor(el.current, styleUrl, () => tRef.current);
    mapa.current = m;
    (async () => {
      const [, trazos] = await Promise.all([m.start(), Promise.all(GRUPOS.map(trazo))]);
      GRUPOS.forEach((g, i) => estadosRef.current.set(g.id, iniciar(g, trazos[i])));
      m.onPick = (id) => setSel(id);
      setListo(true);
    })();
    return () => m.destroy();
  }, [styleUrl]);

  const estados = useMemo(() => [...estadosRef.current.values()].filter((e) => e.g.vista === vista), [vista, listo]); // eslint-disable-line react-hooks/exhaustive-deps

  // escena por vista
  useEffect(() => {
    const m = mapa.current;
    if (!listo || !m?.ready) return;
    m.escena(estados, vista === "migracion" ? PUNTOS : []);
    setSel(null); setSeguir(false); m.setSeguir(false); m.seleccionar(null);
    m.general(2800);
  }, [listo, vista, estados]);

  // reloj de simulación
  useEffect(() => {
    if (!listo) return;
    let last = performance.now(), ui = 0;
    const id = setInterval(() => {
      const now = performance.now(), dt = ((now - last) / 1000) * SIM_X;
      last = now;
      tRef.current += dt;
      for (const e of estadosRef.current.values()) {
        for (const a of avanzar(e, tRef.current, dt)) {
          const llegada = a.titulo.includes("llegó");
          setAvisos((l) => [{ id: ++avisoId.current, grupo: e.g.id, titulo: a.titulo, texto: a.texto, pos: a.pos, ok: llegada }, ...l].slice(0, 3));
        }
      }
      if (now - ui > 450) { ui = now; setTick((x) => x + 1); }
    }, 100);
    return () => clearInterval(id);
  }, [listo]);

  // los avisos se retiran solos
  useEffect(() => {
    if (!avisos.length) return;
    const t = setTimeout(() => setAvisos((l) => l.slice(0, -1)), 12000);
    return () => clearTimeout(t);
  }, [avisos]);

  const elegir = useCallback((id: string | null) => {
    setSel(id); setSeguir(false); mapa.current?.setSeguir(false); mapa.current?.seleccionar(id);
    const e = id ? estadosRef.current.get(id) : null;
    if (e) mapa.current?.grupo(e); else mapa.current?.general(2000);
  }, []);
  useEffect(() => { mapa.current?.seleccionar(sel); }, [sel]);

  const grupoSel = sel ? estadosRef.current.get(sel) ?? null : null;
  const objetivo = grupoSel ?? estados[0] ?? null;

  const lanzar = (id: EscenarioId) => {
    const e = objetivo;
    if (!e) return;
    if (sel !== e.g.id) { setSel(e.g.id); mapa.current?.seleccionar(e.g.id); }
    escenario(e, id, tRef.current);
    setUltimoEsc((u) => ({ ...u, [e.g.id]: id }));
    setTab("linea");
    setSeguir(false); mapa.current?.setSeguir(false);
    const m = mapa.current;
    if (!m) return;
    if (id === "normal") { m.grupo(e); return; }
    const T = () => tRef.current;
    const dest: LngLat = [e.g.destino.lon, e.g.destino.lat];
    if (id === "llegada") { m.irA(sobre(e.tr, Math.max(e.km, e.tr.total - 12)), 11.5, 2600); m.setEncuadre(() => (e.enDestino ? [dest, centro(e)] : [centro(e), sobre(e.tr, Math.min(e.tr.total, e.km + 4))])); return; }
    m.irA(centro(e), 13.5, 2600);
    m.setEncuadre(() => {
      const inc = e.incidente;
      if (!inc) return [centro(e)];
      if (inc.tipo === "separado") return [centro(e), posPersona(e, e.g.personas.find((p) => p.id === inc.persona)!, T())];
      if (inc.tipo === "senal") return [centro(e), ...Object.values(inc.pos)];
      const v = inc.vehiculo ? posVehiculo(e, inc.vehiculo, T()) : posPersona(e, e.g.personas.find((p) => p.id === inc.ids[0])!, T());
      return [v, inc.desde];
    });
  };

  const verAviso = (a: Aviso) => {
    if (estadosRef.current.get(a.grupo)?.g.vista !== vista) setVista(estadosRef.current.get(a.grupo)!.g.vista);
    setSel(a.grupo); mapa.current?.seleccionar(a.grupo); mapa.current?.irA(a.pos, 13.5, 2200);
    setAvisos((l) => l.filter((x) => x.id !== a.id));
  };

  const t = tRef.current;
  const total = estados.reduce((s, e) => s + e.g.personas.length, 0);
  const enAlerta = estados.filter((e) => estatus(e) === "Alerta").length;

  return (
    <div className="acp fixed inset-0 overflow-hidden bg-[#06080c] text-slate-200 select-none">
      <div ref={el} className="absolute inset-0" />
      <div className="fx-vignette pointer-events-none absolute inset-0" />
      {!listo && <div className="absolute inset-0 grid place-items-center font-mono text-[11px] uppercase tracking-[0.3em] text-slate-500">Cargando operación…</div>}

      {/* marca */}
      <div className="glass absolute left-6 top-6 flex w-[380px] items-center gap-3 px-4 py-3">
        <svg width="30" height="30" viewBox="0 0 64 64" aria-hidden><rect width="64" height="64" rx="14" fill="#0f1a1a" /><circle cx="32" cy="32" r="15" fill="none" stroke="#2dd4bf" strokeWidth="5" /><circle cx="32" cy="32" r="5.5" fill="#2dd4bf" /><circle cx="49" cy="16" r="5" fill="#f8fafc" /></svg>
        <div className="min-w-0 flex-1">
          <div className="text-[15px] font-bold tracking-[0.18em] text-white">ACOMPAÑA</div>
          <div className="font-mono text-[10.5px] text-slate-400">Monitoreo y acompañamiento de traslados</div>
        </div>
        <div className="text-right">
          <div className="font-mono text-[14px] font-bold tabular-nums text-white">{hhmm(t, true)}</div>
          <div className="font-mono text-[9.5px] uppercase tracking-wider text-[#5eead4]"><span className="fx-blink mr-1 inline-block h-1.5 w-1.5 rounded-full bg-[#2dd4bf] align-middle" />en vivo · demo</div>
        </div>
      </div>

      {/* izquierda */}
      <aside className="fx-scroll glass absolute bottom-6 left-6 top-[98px] flex w-[380px] flex-col overflow-y-auto px-4 py-3.5">
        <div className="flex rounded-lg bg-black/30 p-0.5 text-[12.5px] font-semibold">
          {([["activaciones", "Activaciones"], ["migracion", "Migración"]] as const).map(([v, lab]) => (
            <button key={v} onClick={() => setVista(v)} className={`flex-1 rounded-md py-1.5 transition-colors ${vista === v ? "bg-white/10 text-white" : "text-slate-500 hover:text-slate-300"}`}>{lab}</button>
          ))}
        </div>
        <div className="mt-3 grid grid-cols-3 gap-2">
          <Stat k={vista === "activaciones" ? "Activaciones" : "Grupos"} v={estados.length} />
          <Stat k="Personas" v={total} />
          <Stat k="En alerta" v={enAlerta} rojo={enAlerta > 0} />
        </div>

        <div className="mt-3 flex flex-col gap-1.5">
          {estados.map((e) => {
            const st = estatus(e), on = sel === e.g.id;
            return (
              <button key={e.g.id} onClick={() => elegir(on ? null : e.g.id)} className={`rounded-xl border px-3 py-2.5 text-left transition-colors ${on ? "border-white/20 bg-white/[0.07]" : "border-white/8 bg-white/[0.02] hover:bg-white/[0.05]"}`}>
                <div className="flex items-center gap-2">
                  <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: rgb(e.g.color) }} />
                  <span className="truncate text-[14px] font-semibold text-white">{e.g.nombre}</span>
                  <span className={`ml-auto shrink-0 rounded-full border px-2 py-0.5 font-mono text-[10px] font-bold ${COLOR_ESTATUS[st]}`}>{st}</span>
                </div>
                <div className="mt-1 truncate text-[12px] text-slate-400">{e.g.origen.nombre} → {e.g.destino.nombre}</div>
                <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full" style={{ width: `${(e.km / e.tr.total) * 100}%`, background: rgb(e.g.color) }} /></div>
                <div className="mt-1 flex justify-between font-mono text-[10.5px] text-slate-500">
                  <span>{e.g.personas.length} personas · {e.g.vehiculos ? `${e.g.vehiculos} ${e.g.vehiculos === 1 ? "vehículo" : "vehículos"}` : "a pie"}</span>
                  <span>{e.enDestino ? "llegó" : `llega ${eta(e, t)}`}</span>
                </div>
              </button>
            );
          })}
        </div>

        <div className="mt-4 border-t border-white/8 pt-3">
          <div className="flex items-baseline justify-between">
            <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-slate-500">Escenarios</span>
            {objetivo && <span className="truncate pl-2 font-mono text-[10.5px] text-slate-400">aplica a <span className="text-white">{objetivo.g.nombre}</span></span>}
          </div>
          <div className="mt-2 grid grid-cols-2 gap-1.5">
            {ESCENARIOS.map((s, i) => (
              <button key={s.id} onClick={() => lanzar(s.id)} disabled={!listo}
                className={`rounded-lg border px-2.5 py-2 text-left transition-colors disabled:opacity-40 ${i === ESCENARIOS.length - 1 ? "col-span-2" : ""} ${objetivo && ultimoEsc[objetivo.g.id] === s.id ? "border-white/25 bg-white/[0.08]" : "border-white/8 bg-white/[0.02] hover:bg-white/[0.06]"}`}>
                <div className="text-[12.5px] font-semibold text-white">{s.titulo}</div>
                <div className="font-mono text-[10px] text-slate-500">{s.desc}</div>
              </button>
            ))}
          </div>
        </div>
        <div className="mt-auto pt-4 text-[11px] leading-snug text-slate-500">
          Ubicación compartida con consentimiento desde la app de registro. Se muestran nombres parciales e ID. Datos simulados para demostración.
        </div>
      </aside>

      {/* derecha: detalle */}
      {grupoSel && <Detalle e={grupoSel} t={t} tab={tab} setTab={setTab} seguir={seguir}
        onSeguir={() => { const v = !seguir; setSeguir(v); mapa.current?.setSeguir(v); if (v) mapa.current?.irA(centro(grupoSel), 12.5, 1800); }}
        onTrayecto={() => { setSeguir(false); mapa.current?.setSeguir(false); mapa.current?.grupo(grupoSel); }}
        onCerrar={() => elegir(null)} onAtender={() => { atender(grupoSel, tRef.current); setTick((x) => x + 1); }} />}

      {/* avisos */}
      <div className="pointer-events-none absolute left-1/2 top-6 flex w-[440px] -translate-x-1/2 flex-col gap-2">
        {avisos.map((a) => (
          <button key={a.id} onClick={() => verAviso(a)} className={`fx-row pointer-events-auto rounded-xl border px-4 py-3 text-left shadow-2xl backdrop-blur ${a.ok ? "border-[#22c55e]/50 bg-[#052e16]/90" : "border-[#ef4444]/60 bg-[#2a0a0a]/92"}`}>
            <div className={`flex items-center gap-2 font-mono text-[10px] font-bold uppercase tracking-[0.2em] ${a.ok ? "text-[#86efac]" : "text-[#fca5a5]"}`}>
              <span className={`h-1.5 w-1.5 rounded-full ${a.ok ? "bg-[#22c55e]" : "fx-blink bg-[#ef4444]"}`} />{a.ok ? "Confirmación" : "Alerta"} · {hhmm(t)}
            </div>
            <div className="mt-1 text-[14px] font-semibold text-white">{a.titulo}</div>
            <div className="mt-0.5 text-[12.5px] leading-snug text-slate-300">{a.texto}</div>
            <div className="mt-1.5 font-mono text-[10.5px] text-slate-400">Ver en el mapa →</div>
          </button>
        ))}
      </div>

      {/* leyenda */}
      <div className="glass absolute bottom-6 left-[420px] flex gap-4 px-4 py-2 font-mono text-[10.5px] text-slate-300">
        <span className="flex items-center gap-1.5"><i className="inline-block h-2 w-2 rounded-full bg-[#2dd4bf]" />integrante</span>
        <span className="flex items-center gap-1.5"><i className="inline-block h-2 w-2 rounded-full bg-slate-500" />sin señal</span>
        <span className="flex items-center gap-1.5"><i className="inline-block h-2 w-2 rounded-full bg-[#ef4444]" />separado / fuera de ruta</span>
        {vista === "activaciones" ? <span className="flex items-center gap-1.5"><i className="inline-block h-2.5 w-2.5 rounded-full border-2 border-[#2dd4bf] bg-black" />vehículo</span>
          : <span className="flex items-center gap-1.5"><i className="inline-block h-2.5 w-2.5 rounded-full border-2 border-[#4ade80]" />albergue / atención</span>}
      </div>
    </div>
  );
}

function eta(e: EstadoGrupo, t: number) {
  const rest = e.tr.total - e.km;
  return hhmm(t + (rest / e.g.velKmh) * 3600);
}

function Stat({ k, v, rojo }: { k: string; v: number; rojo?: boolean }) {
  return (
    <div className="rounded-lg border border-white/8 bg-white/[0.02] px-2.5 py-2">
      <div className="font-mono text-[9.5px] uppercase tracking-wider text-slate-500">{k}</div>
      <div className={`font-mono text-[20px] font-bold leading-tight tabular-nums ${rojo ? "text-[#f87171]" : "text-white"}`}>{n0(v)}</div>
    </div>
  );
}

function Detalle({ e, t, tab, setTab, seguir, onSeguir, onTrayecto, onCerrar, onAtender }: {
  e: EstadoGrupo; t: number; tab: "personas" | "linea"; setTab: (x: "personas" | "linea") => void; seguir: boolean;
  onSeguir: () => void; onTrayecto: () => void; onCerrar: () => void; onAtender: () => void;
}) {
  const st = estatus(e), g = e.g, inc = e.incidente;
  const c = centro(e);
  const filas = g.personas.map((p) => {
    const s = ultimaSenal(e, p, t);
    const sep = inc?.tipo === "separado" && inc.persona === p.id;
    const fuera = inc?.tipo === "fuera" && inc.ids.includes(p.id);
    const d = sep ? km(posPersona(e, p, t), c) : 0;
    const prob = sep ? 3 : s > 120 ? 2 : fuera ? 1 : 0;
    return { p, s, sep, fuera, d, prob };
  }).sort((a, b) => b.prob - a.prob);
  const conSenal = filas.filter((f) => f.s <= 120).length;
  const cercano = g.vista === "migracion" ? PUNTOS.map((x) => ({ x, d: km(c, [x.lon, x.lat]) })).sort((a, b) => a.d - b.d)[0] : null;
  const alertaTxt = inc?.alertado ? e.eventos.filter((x) => x.nivel === "alerta").slice(-1)[0]?.texto : null;

  return (
    <aside className="glass absolute bottom-6 right-6 top-6 flex w-[410px] flex-col px-4 py-4">
      <div className="flex items-start gap-2.5">
        <span className="mt-1 h-8 w-1 rounded-full" style={{ background: rgb(g.color) }} />
        <div className="min-w-0 flex-1">
          <div className="font-mono text-[10px] uppercase tracking-[0.18em] text-slate-500">{g.tipo}</div>
          <div className="text-[19px] font-bold leading-tight text-white">{g.nombre}</div>
          <div className="truncate text-[12.5px] text-slate-400">{g.origen.nombre} → {g.destino.nombre}</div>
        </div>
        <button onClick={onCerrar} className="px-1 text-[18px] leading-none text-slate-500 hover:text-white">×</button>
      </div>

      <div className="mt-3 flex items-center gap-2">
        <span className={`rounded-full border px-2.5 py-0.5 font-mono text-[11px] font-bold ${COLOR_ESTATUS[st]}`}>{st}</span>
        <span className="font-mono text-[11px] text-slate-400">{e.enDestino ? `en ${g.destino.nombre}` : `${n0(e.km)} de ${n0(e.tr.total)} km · llega ${eta(e, t)}`}</span>
      </div>
      <div className="mt-2 h-1 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full transition-all" style={{ width: `${(e.km / e.tr.total) * 100}%`, background: rgb(g.color) }} /></div>

      <div className="mt-3 grid grid-cols-3 gap-2">
        <Stat k="Personas" v={g.personas.length} />
        <div className="rounded-lg border border-white/8 bg-white/[0.02] px-2.5 py-2">
          <div className="font-mono text-[9.5px] uppercase tracking-wider text-slate-500">{g.vehiculos ? "Vehículos" : "Traslado"}</div>
          <div className="font-mono text-[20px] font-bold leading-tight text-white">{g.vehiculos || "A pie"}</div>
        </div>
        <div className="rounded-lg border border-white/8 bg-white/[0.02] px-2.5 py-2">
          <div className="font-mono text-[9.5px] uppercase tracking-wider text-slate-500">Con señal</div>
          <div className={`font-mono text-[20px] font-bold leading-tight tabular-nums ${conSenal < g.personas.length ? "text-[#fcd34d]" : "text-white"}`}>{conSenal}<span className="text-[12px] text-slate-500">/{g.personas.length}</span></div>
        </div>
      </div>

      {inc?.alertado && (
        <div className={`mt-3 rounded-xl border px-3 py-2.5 ${e.atendida ? "border-[#f59e0b]/40 bg-[#f59e0b]/10" : "border-[#ef4444]/50 bg-[#ef4444]/12"}`}>
          <div className={`font-mono text-[10px] font-bold uppercase tracking-[0.18em] ${e.atendida ? "text-[#fcd34d]" : "text-[#fca5a5]"}`}>{e.atendida ? "En atención" : "Alerta activa"}</div>
          <div className="mt-0.5 text-[13px] leading-snug text-white">{alertaTxt}</div>
          {!e.atendida && <button onClick={onAtender} className="mt-2 rounded-lg border border-white/20 px-3 py-1 text-[12px] font-semibold text-white hover:bg-white/10">Marcar en atención</button>}
        </div>
      )}
      {cercano && (
        <div className="mt-3 rounded-xl border border-[#4ade80]/25 bg-[#4ade80]/[0.06] px-3 py-2 text-[12.5px]">
          <span className="text-slate-400">Punto de apoyo más cercano: </span><span className="font-semibold text-white">{cercano.x.nombre}</span><span className="text-slate-400"> · {cercano.d < 1 ? "menos de 1 km" : `${n0(cercano.d)} km`}</span>
        </div>
      )}

      <div className="mt-3 flex gap-2">
        <button onClick={onTrayecto} className="flex-1 rounded-lg border border-white/12 py-1.5 text-[12px] font-semibold text-slate-200 hover:bg-white/[0.06]">Ver trayecto</button>
        <button onClick={onSeguir} className={`flex-1 rounded-lg border py-1.5 text-[12px] font-semibold ${seguir ? "border-[#2dd4bf]/50 bg-[#2dd4bf]/10 text-[#5eead4]" : "border-white/12 text-slate-200 hover:bg-white/[0.06]"}`}>{seguir ? "Siguiendo al grupo" : "Seguir al grupo"}</button>
      </div>

      <div className="mt-3 flex gap-4 border-b border-white/8 text-[12.5px] font-semibold">
        {([["personas", "Integrantes"], ["linea", "Línea de tiempo"]] as const).map(([k, lab]) => (
          <button key={k} onClick={() => setTab(k)} className={`-mb-px border-b-2 pb-1.5 ${tab === k ? "border-white text-white" : "border-transparent text-slate-500 hover:text-slate-300"}`}>{lab}</button>
        ))}
      </div>

      {tab === "personas" ? (
        <div className="fx-scroll mt-2 flex min-h-0 flex-1 flex-col overflow-y-auto pr-1">
          {filas.map(({ p, s, sep, fuera, d }) => (
            <div key={p.id} className="flex items-center gap-2.5 border-b border-white/[0.04] py-1.5">
              <span className={`h-2 w-2 shrink-0 rounded-full ${sep ? "bg-[#ef4444]" : s > 120 ? "bg-slate-500" : fuera ? "bg-[#f59e0b]" : "bg-[#2dd4bf]"}`} />
              <div className="min-w-0 flex-1">
                <div className="truncate text-[13px] text-slate-100">{p.alias} <span className="font-mono text-[10.5px] text-slate-500">{p.id}</span></div>
              </div>
              {g.vehiculos > 0 && <span className="font-mono text-[10.5px] text-slate-500">veh {p.vehiculo}</span>}
              <span className={`w-[118px] text-right font-mono text-[10.5px] ${sep ? "text-[#fca5a5]" : s > 120 ? "text-[#fcd34d]" : "text-slate-400"}`}>
                {sep ? `separado · ${d < 1 ? `${Math.round(d * 1000)} m` : `${d.toFixed(1)} km`}` : s > 120 ? `sin señal ${hace(s)}` : hace(s)}
              </span>
            </div>
          ))}
        </div>
      ) : (
        <ol className="fx-scroll mt-2 flex min-h-0 flex-1 flex-col overflow-y-auto pr-1">
          {[...e.eventos].reverse().map((ev, i) => (
            <li key={i} className="flex gap-2.5 py-1.5">
              <span className="w-[74px] shrink-0 font-mono text-[11px] text-slate-400">{hhmmDia(ev.t)}</span>
              <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${NIVEL[ev.nivel]}`} />
              <span className={`text-[12.5px] leading-snug ${ev.nivel === "alerta" ? "text-[#fecaca]" : "text-slate-200"}`}>{ev.texto}</span>
            </li>
          ))}
        </ol>
      )}
    </aside>
  );
}
