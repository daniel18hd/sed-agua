// Motor de simulación del monitoreo: avance de cada grupo, posición y estado de cada integrante (señal, batería,
// velocidad, precisión), rastro reciente, escenarios con varias personas y alertas. Datos simulados.
import type { Grupo, LngLat, EscenarioId, Persona } from "./datos";

export const SIM_X = 30;                       // segundos simulados por segundo real
export const HORA_BASE = 7 * 3600 + 42 * 60;   // 07:42:00 al iniciar el demo
export const SIN_SENAL_S = 120;                // sin reportar por más de 2 min = sin señal
export const BATERIA_BAJA = 15;                // %

// ------------------------------------------------------------------ geometría
export const R = 6371;
export function km(a: LngLat, b: LngLat): number {
  const dLat = ((b[1] - a[1]) * Math.PI) / 180, dLon = ((b[0] - a[0]) * Math.PI) / 180;
  const s = Math.sin(dLat / 2) ** 2 + Math.cos((a[1] * Math.PI) / 180) * Math.cos((b[1] * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}
export interface Trayecto { path: LngLat[]; cum: number[]; total: number }
export function trayecto(path: LngLat[]): Trayecto {
  const cum = [0];
  for (let i = 1; i < path.length; i++) cum.push(cum[i - 1] + km(path[i - 1], path[i]));
  return { path, cum, total: cum[cum.length - 1] };
}
export function sobre(t: Trayecto, d: number): LngLat {
  const x = Math.max(0, Math.min(t.total, d));
  let lo = 0, hi = t.cum.length - 1;
  while (hi - lo > 1) { const m = (lo + hi) >> 1; if (t.cum[m] < x) lo = m; else hi = m; }
  const f = (x - t.cum[lo]) / (t.cum[hi] - t.cum[lo] || 1);
  return [t.path[lo][0] + (t.path[hi][0] - t.path[lo][0]) * f, t.path[lo][1] + (t.path[hi][1] - t.path[lo][1]) * f];
}
function direccion(t: Trayecto, d: number): { dir: LngLat; perp: LngLat } {
  const a = sobre(t, d - 0.3), b = sobre(t, d + 0.3);
  const k = Math.cos((a[1] * Math.PI) / 180);
  let dx = (b[0] - a[0]) * k, dy = b[1] - a[1];
  const n = Math.hypot(dx, dy) || 1; dx /= n; dy /= n;
  return { dir: [dx / k, dy], perp: [-dy / k, dx] };
}
export function kmEnTrayecto(t: Trayecto, p: LngLat): number {
  let best = 0, bd = Infinity;
  for (let i = 0; i < t.path.length; i += Math.max(1, Math.floor(t.path.length / 1500))) { const d = km(t.path[i], p); if (d < bd) { bd = d; best = i; } }
  return t.cum[best];
}
function distSeg(p: LngLat, a: LngLat, b: LngLat): number {
  const k = Math.cos((p[1] * Math.PI) / 180) * 111.32, q = 110.57;
  const ax = (a[0] - p[0]) * k, ay = (a[1] - p[1]) * q, bx = (b[0] - p[0]) * k, by = (b[1] - p[1]) * q;
  const dx = bx - ax, dy = by - ay, L = dx * dx + dy * dy;
  const u = L ? Math.max(0, Math.min(1, -(ax * dx + ay * dy) / L)) : 0;
  return Math.hypot(ax + u * dx, ay + u * dy);
}
/** Distancia (km) de un punto al trayecto; si se da `cerca`, solo revisa ±25 km alrededor de ese avance. */
export function distATrayecto(t: Trayecto, p: LngLat, cerca?: number): number {
  let i0 = 0, i1 = t.path.length - 1;
  if (cerca != null) {
    const a = t.cum.findIndex((c) => c > cerca - 25), b = t.cum.findIndex((c) => c > cerca + 25);
    i0 = Math.max(0, (a < 0 ? t.path.length - 1 : a) - 1); i1 = b < 0 ? t.path.length - 1 : b;
  }
  let bd = Infinity;
  for (let i = i0; i < i1; i++) bd = Math.min(bd, distSeg(p, t.path[i], t.path[i + 1]));
  return Number.isFinite(bd) ? bd : km(p, t.path[t.path.length - 1]);
}
export const hash = (s: string) => { let h = 2166136261; for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619); return ((h >>> 0) % 10000) / 10000; };
const mover = (p: LngLat, v: LngLat, kmD: number): LngLat => [p[0] + v[0] * kmD / 111, p[1] + v[1] * kmD / 111];

// ------------------------------------------------------------------ estado
export type Nivel = "info" | "ok" | "aviso" | "alerta";
export interface Evento { t: number; nivel: Nivel; texto: string }
export interface Sep { id: string; desde: LngLat; dir: LngLat; velKmh: number; maxKm: number; t0: number; principal: boolean }
export interface Incidente {
  tipo: Exclude<EscenarioId, "normal">; t0: number; alertado: boolean;
  separados: Sep[];
  sinSenal: Record<string, { pos: LngLat; t0: number }>;
  pendSenal: { id: string; en: number }[];               // perderán la señal más adelante
  bateria: Record<string, number>;                        // batería forzada por el escenario
  fuera?: { ids: string[]; vehiculo: number; desde: LngLat; dir: LngLat };
}
export interface EstadoGrupo {
  g: Grupo; tr: Trayecto; km: number; km0: number;
  llegando: boolean; velLlegada: number; enDestino: boolean; tLlegada: number;
  incidente: Incidente | null; atendida: boolean;
  eventos: Evento[]; pasos: { nombre: string; km: number; hecho: boolean }[];
}
export type Estatus = "En ruta" | "Detenido" | "Alerta" | "En destino";
export type EstadoP = "En ruta" | "Separado" | "Sin señal" | "Detenido" | "Llegó";

export function iniciar(g: Grupo, path: LngLat[]): EstadoGrupo {
  const tr = trayecto(path);
  const km0 = tr.total * g.progreso0;
  const pasos = g.via.map((v) => ({ nombre: v.nombre, km: kmEnTrayecto(tr, [v.lon, v.lat]), hecho: false }));
  const vel = g.velKmh / 3600;
  const eventos: Evento[] = [
    { t: -km0 / vel - 1800, nivel: "info", texto: `Activación registrada · ${g.personas.length} personas${g.vehiculos ? ` · ${g.vehiculos} ${g.vehiculos === 1 ? "vehículo" : "vehículos"}` : " · a pie"} · ubicación compartida con consentimiento` },
    { t: -km0 / vel, nivel: "info", texto: `Salida de ${g.origen.nombre}` },
  ];
  for (const p of pasos) if (p.km < km0) { p.hecho = true; eventos.push({ t: -(km0 - p.km) / vel, nivel: "info", texto: `Paso por ${p.nombre}` }); }
  return { g, tr, km: km0, km0, llegando: false, velLlegada: 0, enDestino: false, tLlegada: 0, incidente: null, atendida: false, eventos, pasos };
}

const vel = (e: EstadoGrupo) => (e.llegando ? Math.max(e.g.velKmh / 3600, e.velLlegada) : e.g.velKmh / 3600);
/** Avance (km) del grupo en el instante tt (tt ≤ t), para dibujar el rastro. */
function kmEn(e: EstadoGrupo, t: number, tt: number): number {
  if (tt >= t) return e.km;
  if (e.enDestino) return tt >= e.tLlegada ? e.tr.total : Math.max(0, e.tr.total - (e.g.velKmh / 3600) * (e.tLlegada - tt));
  return Math.max(0, e.km - vel(e) * (t - tt));
}
const vehiculoKm = (kmG: number, v: number) => kmG - Math.max(0, v - 1) * 0.9;

/** Posición de una persona en el instante tt (por defecto, ahora). */
export function posPersona(e: EstadoGrupo, p: Persona, t: number, tt = t): LngLat {
  const inc = e.incidente;
  const s = inc?.sinSenal[p.id];
  if (s && tt >= s.t0) return s.pos;
  const sep = inc?.separados.find((x) => x.id === p.id);
  if (sep && tt >= sep.t0) return mover(sep.desde, sep.dir, Math.min(sep.maxKm, ((tt - sep.t0) / 3600) * sep.velKmh));
  const h = hash(p.id), h2 = hash(p.id + "y");
  const f = inc?.fuera;
  if (f && f.ids.includes(p.id) && tt >= inc!.t0) {
    const c = mover(f.desde, f.dir, Math.min(2.1, ((tt - inc!.t0) / 120) * 2.1));
    return [c[0] + (h - 0.5) * 0.0006, c[1] + (h2 - 0.5) * 0.0006];
  }
  const kmG = kmEn(e, t, tt);
  let pos: LngLat;
  if (!e.g.vehiculos) {
    const base = sobre(e.tr, kmG - h * 2.5);
    const w = Math.sin(tt / 240 + h * 20) * 0.00025;
    pos = [base[0] + (h2 - 0.5) * 0.0016 + w, base[1] + (hash(p.id + "z") - 0.5) * 0.0016];
  } else {
    // alrededor de su vehículo: 6–30 m
    pos = desplazar(sobre(e.tr, vehiculoKm(kmG, p.vehiculo)), h * Math.PI * 2, 6 + h2 * 24);
  }
  // en destino: cada persona se acomoda en un punto propio a 50–400 m de la llegada (calles y plaza)
  if (e.enDestino && tt >= e.tLlegada) {
    const dest: LngLat = [e.g.destino.lon, e.g.destino.lat];
    const lugar = desplazar(dest, hash(p.id + "a") * Math.PI * 2, 50 + Math.sqrt(hash(p.id + "r")) * 350);
    const k = Math.min(1, (tt - e.tLlegada) / 150);
    const f = k * k * (3 - 2 * k);
    return [pos[0] + (lugar[0] - pos[0]) * f, pos[1] + (lugar[1] - pos[1]) * f];
  }
  return pos;
}
/** Punto a `m` metros en dirección `ang` (radianes). */
function desplazar(p: LngLat, ang: number, m: number): LngLat {
  return [p[0] + (Math.cos(ang) * m) / (111320 * Math.cos((p[1] * Math.PI) / 180)), p[1] + (Math.sin(ang) * m) / 110570];
}
export function posVehiculo(e: EstadoGrupo, v: number, t: number): LngLat {
  const f = e.incidente?.fuera;
  if (f && f.vehiculo === v) return mover(f.desde, f.dir, Math.min(2.1, ((t - e.incidente!.t0) / 120) * 2.1));
  return sobre(e.tr, vehiculoKm(e.km, v));
}
export function centro(e: EstadoGrupo): LngLat { if (e.enDestino) return [e.g.destino.lon, e.g.destino.lat]; return sobre(e.tr, e.g.vehiculos ? e.km - (e.g.vehiculos - 1) * 0.45 : e.km - 1.25); }

/** Rastro reciente (últimos ~15 min) de una persona. */
export function rastro(e: EstadoGrupo, p: Persona, t: number): LngLat[] {
  const out: LngLat[] = [];
  for (let k = 20; k >= 0; k--) out.push(posPersona(e, p, t, t - k * 45));
  return out;
}

/** Segundos desde la última señal. Algunas personas tienen señal intermitente aun en operación normal. */
export function ultimaSenal(e: EstadoGrupo, p: Persona, t: number): number {
  const s = e.incidente?.sinSenal[p.id];
  if (s && t >= s.t0) return Math.max(0, t - s.t0) + hash(p.id) * 20;
  const h = hash(p.id + "s");
  if (h < 0.018 && !e.enDestino) return 150 + h * 16000;  // intermitente: 2.5–7 min (en ruta)
  return Math.floor((t + hash(p.id) * 60) % 60);
}
export function bateria(e: EstadoGrupo, p: Persona, t: number): number {
  const f = e.incidente?.bateria[p.id];
  if (f != null) return f;
  const h = hash(p.id + "b");
  const base = h < 0.05 ? 6 + h * 180 : 22 + h * 78;     // ~5% arranca con batería baja
  return Math.max(1, Math.round(base - (Math.max(0, t) / 3600) * 2));
}

export interface FichaPersona {
  p: Persona; pos: LngLat; bat: number; senal: number; estado: EstadoP; velKmh: number; precisionM: number;
  distGrupo: number; distRuta: number; causa: string; nivel: Nivel;
}
export function estadoPersona(e: EstadoGrupo, p: Persona, t: number): FichaPersona {
  const inc = e.incidente, pos = posPersona(e, p, t), bat = bateria(e, p, t), senal = ultimaSenal(e, p, t);
  const sep = inc?.separados.find((x) => x.id === p.id && t >= x.t0);
  const fuera = !!inc?.fuera?.ids.includes(p.id);
  const sin = senal > SIN_SENAL_S;
  const estado: EstadoP = sin ? "Sin señal" : sep ? "Separado" : fuera ? "Detenido" : e.enDestino ? "Llegó" : "En ruta";
  const h = hash(p.id + "v");
  const moviendo = sep ? ((t - sep.t0) / 3600) * sep.velKmh < sep.maxKm : !fuera && !e.enDestino;
  const velKmh = sin ? 0 : sep ? (moviendo ? sep.velKmh : 0) : !moviendo ? 0 : e.g.vehiculos ? Math.round(e.g.velKmh - 6 + h * 12) : +(3 + h * 2).toFixed(1);
  const precisionM = Math.round(sin ? 35 + h * 30 : sep ? 12 + h * 14 : 4 + h * 12);
  const distGrupo = km(pos, centro(e));
  const distRuta = distATrayecto(e.tr, pos, e.km);
  let causa = "Sin novedades · reporta con normalidad";
  let nivel: Nivel = "ok";
  if (estado === "Sin señal") {
    nivel = "alerta";
    causa = bat <= 10 ? `Batería ${bat}% – probable apagado del equipo` : inc?.tipo === "senal" && e.g.vehiculos ? `Batería ${bat}% – posible zona sin cobertura; su vehículo sigue en ruta` : `Batería ${bat}% – posible pérdida de señal real; contactar al enlace del grupo`;
    if (!inc && senal < 480) { nivel = "aviso"; causa = `Batería ${bat}% – señal intermitente, sin indicio de riesgo`; }
  } else if (estado === "Separado") {
    nivel = distGrupo > 0.5 ? "alerta" : "aviso";
    causa = bat >= 30 ? `Batería ${bat}% – posible separación real; contactar de inmediato` : `Batería ${bat}% – separación con riesgo de quedarse sin señal`;
    if (distGrupo <= 0.5) causa = `Batería ${bat}% – se rezagó del grupo; dar seguimiento`;
  } else if (estado === "Detenido") {
    nivel = "alerta"; causa = "Vehículo detenido fuera de ruta – verificar con el enlace a bordo";
  } else if (estado === "Llegó") {
    causa = "Confirmado en destino";
  }
  if (nivel === "ok" && bat <= BATERIA_BAJA) { nivel = "aviso"; causa = `Batería ${bat}% – pedir que cargue el equipo antes de perder señal`; }
  return { p, pos, bat, senal, estado, velKmh, precisionM, distGrupo, distRuta, causa, nivel };
}

export function estatus(e: EstadoGrupo): Estatus {
  if (e.enDestino) return e.incidente?.alertado && !e.atendida && e.incidente.tipo !== "llegada" ? "Alerta" : "En destino";
  if (e.incidente?.alertado && !e.atendida) return "Alerta";
  if (e.incidente?.fuera) return "Detenido";
  return "En ruta";
}

export const hhmm = (t: number, seg = false) => {
  const s = ((Math.floor(HORA_BASE + t) % 86400) + 86400) % 86400;
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}${seg ? `:${String(x).padStart(2, "0")}` : ""}`;
};
export const hhmmDia = (t: number) => {
  const d = Math.floor((HORA_BASE + t) / 86400);
  return d === 0 ? hhmm(t) : d === -1 ? `ayer ${hhmm(t)}` : `${d < 0 ? `hace ${-d} días` : `+${d} d`} ${hhmm(t)}`;
};
export const kmTxt = (d: number) => (d < 1 ? `${Math.round(d * 1000)} m` : `${d.toFixed(1)} km`);

const nuevoInc = (tipo: Incidente["tipo"], t: number): Incidente => ({ tipo, t0: t, alertado: false, separados: [], sinSenal: {}, pendSenal: [], bateria: {} });
const elegir = (g: Grupo, n: number, salto: number, desde = 0) => Array.from({ length: n }, (_, i) => g.personas[(desde + i * salto) % g.personas.length]);

/** Avanza la simulación dt segundos simulados. Devuelve las alertas nuevas. */
export function avanzar(e: EstadoGrupo, t: number, dt: number): { titulo: string; texto: string; pos: LngLat; ok?: boolean }[] {
  const nuevas: { titulo: string; texto: string; pos: LngLat; ok?: boolean }[] = [];
  const g = e.g, inc = e.incidente;
  if (inc) for (const x of [...inc.pendSenal]) if (t >= x.en) {
    const p = g.personas.find((q) => q.id === x.id)!;
    inc.sinSenal[x.id] = { pos: posPersona(e, p, t), t0: t };
    inc.pendSenal = inc.pendSenal.filter((q) => q !== x);
    e.eventos.push({ t, nivel: "aviso", texto: `${p.alias} (${p.id}) deja de reportar · batería ${bateria(e, p, t)}%` });
  }
  if (!e.enDestino) {
    e.km = Math.min(e.tr.total, e.km + vel(e) * dt);
    for (const p of e.pasos) if (!p.hecho && e.km >= p.km) { p.hecho = true; e.eventos.push({ t, nivel: "info", texto: `Paso por ${p.nombre}` }); }
    if (e.km >= e.tr.total - 0.01) {
      e.enDestino = true; e.llegando = false; e.tLlegada = t;
      const dest: LngLat = [g.destino.lon, g.destino.lat];
      if (inc?.tipo === "llegada") {
        // dos personas sin confirmar: una se quedó a ~1 km con buena batería; otra sin señal con batería agotada
        const [a, b] = elegir(g, 2, 17, 11);
        const { perp, dir } = direccion(e.tr, e.tr.total - 1.5);
        inc.separados.push({ id: a.id, desde: mover(dest, [-dir[0], -dir[1]], 1.1), dir: perp, velKmh: 2, maxKm: 0.25, t0: t, principal: true });
        inc.bateria[a.id] = 64; inc.bateria[b.id] = 1;
        inc.sinSenal[b.id] = { pos: mover(dest, [-dir[0], -dir[1]], 2.3), t0: t - 420 };
        inc.alertado = true;
      }
      const sinConf = inc?.tipo === "llegada" ? 2 : inc && !e.atendida ? Object.keys(inc.sinSenal).length + inc.separados.length : 0;
      const n = g.personas.length;
      e.eventos.push({ t, nivel: sinConf ? "alerta" : "ok", texto: `Llegada a ${g.destino.nombre} · ${n - sinConf}/${n} integrantes confirmados${sinConf ? ` · ${sinConf} sin confirmar` : ""}` });
      nuevas.push({ titulo: `${g.nombre} llegó a destino`, texto: `${n - sinConf} de ${n} integrantes confirmados en ${g.destino.nombre}.${sinConf ? ` ${sinConf} sin confirmar: revisa sus fichas.` : ""}`, pos: dest, ok: !sinConf });
    }
  }
  if (inc && !inc.alertado) {
    if (inc.tipo === "separado") {
      const s = inc.separados.find((x) => x.principal)!;
      const p = g.personas.find((x) => x.id === s.id)!;
      const d = km(posPersona(e, p, t), centro(e));
      if (d > 0.5) {
        inc.alertado = true;
        e.eventos.push({ t, nivel: "alerta", texto: `Integrante separado · ${p.alias} (${p.id}) a ${kmTxt(d)} del grupo · ${inc.separados.length - 1} más con distancia irregular` });
        nuevas.push({ titulo: `${g.nombre} · integrante separado`, texto: `${p.alias} (${p.id}) está a ${kmTxt(d)} de su grupo y la distancia aumenta. Hay ${inc.separados.length - 1} integrantes más fuera del grupo.`, pos: posPersona(e, p, t) });
      }
    } else if (inc.tipo === "senal") {
      if (t - inc.t0 > 180) {
        inc.alertado = true;
        const ids = Object.keys(inc.sinSenal);
        const bajas = ids.filter((id) => (inc.bateria[id] ?? 50) <= 10).length;
        e.eventos.push({ t, nivel: "alerta", texto: `Pérdida de señal · ${ids.length} integrantes sin reportar desde ${hhmm(inc.t0)} · ${bajas} con batería crítica` });
        nuevas.push({ titulo: `${g.nombre} · pérdida de señal`, texto: `${ids.length} integrantes sin señal desde las ${hhmm(inc.t0)}; ${bajas} con batería crítica. Se conserva su última ubicación.`, pos: Object.values(inc.sinSenal)[0].pos });
      }
    } else if (inc.tipo === "fuera" && inc.fuera) {
      if (t - inc.t0 > 150) {
        inc.alertado = true;
        const pos = inc.fuera.vehiculo ? posVehiculo(e, inc.fuera.vehiculo, t) : posPersona(e, g.personas.find((x) => x.id === inc.fuera!.ids[0])!, t);
        const d = distATrayecto(e.tr, pos, e.km);
        const quien = g.vehiculos ? `Vehículo ${inc.fuera.vehiculo}` : `Subgrupo de ${inc.fuera.ids.length} personas`;
        e.eventos.push({ t, nivel: "alerta", texto: `Detenido fuera de ruta · ${quien} a ${kmTxt(d)} de la ruta` });
        nuevas.push({ titulo: `${g.nombre} · detenido fuera de ruta`, texto: `${quien} detenido a ${kmTxt(d)} de la ruta desde las ${hhmm(inc.t0)}. ${inc.fuera.ids.length} personas a bordo.`, pos });
      }
    } else if (inc.tipo === "bateria") {
      if (t - inc.t0 > 60) {
        inc.alertado = true;
        const n = Object.keys(inc.bateria).length;
        e.eventos.push({ t, nivel: "alerta", texto: `Batería baja · ${n} integrantes con 15% o menos · ${inc.pendSenal.length + Object.keys(inc.sinSenal).length} por apagarse` });
        nuevas.push({ titulo: `${g.nombre} · batería baja`, texto: `${n} integrantes con batería de 15% o menos. Algunos equipos podrían apagarse en minutos.`, pos: centro(e) });
      }
    }
  }
  return nuevas;
}

/** Aplica un escenario de demo a un grupo. */
export function escenario(e: EstadoGrupo, id: EscenarioId, t: number) {
  const g = e.g;
  const reinicioDestino = () => { if (e.enDestino) { e.enDestino = false; e.km = e.km0; for (const p of e.pasos) p.hecho = p.km < e.km; } };
  if (id === "normal") {
    if (e.incidente || e.enDestino || e.llegando) e.eventos.push({ t, nivel: "ok", texto: "Operación normal · todos los integrantes reportando" });
    e.incidente = null; e.atendida = false; e.llegando = false; reinicioDestino();
    return;
  }
  reinicioDestino();
  e.atendida = false; e.llegando = false;
  const inc = nuevoInc(id, t);
  e.incidente = inc;
  const { perp } = direccion(e.tr, e.km);
  const neg: LngLat = [-perp[0], -perp[1]];
  if (id === "separado") {
    const [a, b, c] = elegir(g, 3, 23, Math.floor(g.personas.length * 0.37));
    inc.separados.push({ id: a.id, desde: posPersona(e, a, t), dir: perp, velKmh: 14, maxKm: 2.6, t0: t, principal: true });
    inc.separados.push({ id: b.id, desde: posPersona(e, b, t), dir: neg, velKmh: 4, maxKm: 0.4, t0: t, principal: false });
    inc.separados.push({ id: c.id, desde: posPersona(e, c, t), dir: perp, velKmh: 9, maxKm: 0.9, t0: t, principal: false });
    inc.bateria[a.id] = 78; inc.bateria[b.id] = 52; inc.bateria[c.id] = 4;
    inc.pendSenal.push({ id: c.id, en: t + 150 });
    e.eventos.push({ t, nivel: "aviso", texto: `${a.alias} (${a.id}) y 2 integrantes más se alejan del grupo` });
  } else if (id === "senal") {
    const v = g.vehiculos;
    const ps = (v ? g.personas.filter((p) => p.vehiculo === v) : g.personas.filter((_, i) => i % 15 === 4)).slice(0, v ? 7 : 12);
    const bats = [3, 61, 2, 84, 47, 6, 72, 18, 5, 66, 38, 90];
    ps.forEach((p, i) => { inc.bateria[p.id] = bats[i % bats.length]; inc.sinSenal[p.id] = { pos: posPersona(e, p, t), t0: t - (i % 4) * 75 }; });
    e.eventos.push({ t, nivel: "aviso", texto: `${ps.length} integrantes dejan de reportar ubicación` });
  } else if (id === "fuera") {
    const v = g.vehiculos;
    const ids = (v ? g.personas.filter((p) => p.vehiculo === v) : g.personas.filter((_, i) => i % 9 === 0)).map((p) => p.id);
    const desde = v ? posVehiculo(e, v, t) : sobre(e.tr, e.km - 1.2);
    inc.fuera = { ids, vehiculo: v, desde, dir: neg };
    e.eventos.push({ t, nivel: "aviso", texto: `${v ? `Vehículo ${v}` : `Subgrupo de ${ids.length} personas`} sale de la ruta prevista` });
  } else if (id === "bateria") {
    const ps = elegir(g, 9, 13, 5);
    const bats = [3, 7, 12, 2, 14, 9, 11, 5, 13];
    ps.forEach((p, i) => { inc.bateria[p.id] = bats[i]; });
    inc.pendSenal.push({ id: ps[0].id, en: t + 120 }, { id: ps[3].id, en: t + 200 });
    e.eventos.push({ t, nivel: "aviso", texto: `${ps.length} equipos reportan batería baja` });
  } else if (id === "llegada") {
    e.llegando = true; e.velLlegada = (e.tr.total - e.km) / 200;
    e.eventos.push({ t, nivel: "info", texto: `Último tramo hacia ${g.destino.nombre}` });
  }
}

export function atender(e: EstadoGrupo, t: number) {
  if (!e.incidente?.alertado || e.atendida) return;
  e.atendida = true;
  e.eventos.push({ t, nivel: "ok", texto: "Alerta en atención · enlace de seguimiento contactó al grupo" });
}
