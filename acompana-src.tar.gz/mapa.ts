// Mapa del tablero: globo + capas nativas del mapa (sin librerías extra de WebGL) para trayectos, vehículos,
// integrantes, alertas y albergues. Un solo bucle de animación; los datos se refrescan ~15 veces por segundo.
import maplibregl, { type Map as MLMap, type StyleSpecification, type LngLatBoundsLike, type GeoJSONSource } from "maplibre-gl";
import type { LngLat, Punto } from "@/acompana/lib/datos";
import { type EstadoGrupo, posPersona, posVehiculo, centro, ultimaSenal, sobre, bateria, rastro, estadoPersona, kmTxt, SIN_SENAL_S, BATERIA_BAJA } from "@/acompana/lib/sim";

type RGB = [number, number, number];
const ROJO: RGB = [239, 68, 68], AMBAR: RGB = [245, 158, 11], GRIS: RGB = [100, 116, 139], VERDE: RGB = [74, 222, 128];
const EASE = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
const PAD = { top: 110, bottom: 90, left: 440, right: 470 };
const css = (c: RGB) => `rgb(${c[0]},${c[1]},${c[2]})`;
const FC = (features: any[]) => ({ type: "FeatureCollection", features } as any);
const pt = (p: LngLat, props: any) => ({ type: "Feature", geometry: { type: "Point", coordinates: p }, properties: props });
const ln = (c: LngLat[], props: any) => ({ type: "Feature", geometry: { type: "LineString", coordinates: c }, properties: props });

async function loadStyle(url: string): Promise<StyleSpecification> {
  try {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 5000);
    const r = await fetch(url, { signal: ctl.signal });
    clearTimeout(t);
    if (!r.ok) throw new Error(String(r.status));
    return (await r.json()) as StyleSpecification;
  } catch {
    return { version: 8, sources: {}, layers: [{ id: "bg", type: "background", paint: { "background-color": "#07090d" } }] } as any;
  }
}
function bbox(pts: LngLat[], pad = 0): [LngLat, LngLat] {
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (const [x, y] of pts) { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); }
  return [[x0 - pad, y0 - pad], [x1 + pad, y1 + pad]];
}
function etiqueta(texto: string, clase: string): HTMLElement {
  const d = document.createElement("div");
  d.className = clase;
  d.textContent = texto;
  return d;
}

export class Monitor {
  map!: MLMap;
  ready = false;
  private raf = 0;
  private destroyed = false;
  private estados: EstadoGrupo[] = [];
  private puntos: Punto[] = [];
  private sel: string | null = null;
  private seguir = false;
  private ultSeguir = 0;
  private ultDatos = 0;
  private estaticoSucio = true;
  private encuadre: (() => LngLat[]) | null = null;
  private recorridos = new Map<string, { km: number; path: LngLat[] }>();
  private marcas: maplibregl.Marker[] = [];
  onPick: (id: string) => void = () => {};
  onPickPersona: (grupo: string, persona: string) => void = () => {};
  private persona: { grupo: string; id: string } | null = null;
  private etiquetaSel: maplibregl.Marker | null = null;

  constructor(private el: HTMLElement, private styleUrl: string, private tiempo: () => number) {}

  async start() {
    const style = await loadStyle(this.styleUrl);
    if (this.destroyed) return;
    const m = new maplibregl.Map({ container: this.el, style, center: [-101.8, 22.6], zoom: 4.4, renderWorldCopies: false, attributionControl: { compact: true }, pixelRatio: Math.min(devicePixelRatio || 1, 2), fadeDuration: 0 } as any);
    this.map = m;
    await new Promise<void>((res) => { let d = false; const ok = () => { if (!d) { d = true; res(); } }; m.once("style.load", ok); m.once("load", ok); if (m.isStyleLoaded()) ok(); });
    m.setPadding(PAD as any);
    for (const l of m.getStyle().layers ?? []) if (l.type === "background") m.setPaintProperty(l.id, "background-color", "#06080c");

    for (const s of ["pendiente", "recorrido", "lineas", "puntos", "od", "anillos", "gente", "vehiculos", "rastro", "linea-sel", "sel"]) m.addSource(s, { type: "geojson", data: FC([]) });
    m.addLayer({ id: "pendiente", type: "line", source: "pendiente", layout: { "line-cap": "round", "line-join": "round" }, paint: { "line-color": ["get", "c"], "line-width": 2, "line-opacity": ["*", 0.3, ["get", "a"]] } });
    m.addLayer({ id: "recorrido", type: "line", source: "recorrido", layout: { "line-cap": "round", "line-join": "round" }, paint: { "line-color": ["get", "c"], "line-width": 4, "line-opacity": ["*", 0.92, ["get", "a"]] } });
    m.addLayer({ id: "lineas", type: "line", source: "lineas", paint: { "line-color": "#ef4444", "line-width": 2, "line-dasharray": [2, 1.5] } });
    m.addLayer({ id: "puntos", type: "circle", source: "puntos", paint: { "circle-radius": 6, "circle-color": ["get", "c"], "circle-opacity": 0.25, "circle-stroke-color": ["get", "c"], "circle-stroke-width": 1.5 } });
    m.addLayer({ id: "od", type: "circle", source: "od", paint: { "circle-radius": ["case", ["get", "o"], 5, 7], "circle-color": ["case", ["get", "o"], "#06080c", ["get", "c"]], "circle-stroke-color": ["get", "c"], "circle-stroke-width": 2, "circle-opacity": ["get", "a"], "circle-stroke-opacity": ["get", "a"] } });
    m.addLayer({ id: "anillos", type: "circle", source: "anillos", paint: { "circle-radius": ["get", "r"], "circle-color": "rgba(0,0,0,0)", "circle-stroke-color": ["get", "c"], "circle-stroke-width": 2, "circle-stroke-opacity": ["get", "op"] } });
    m.addLayer({ id: "gente", type: "circle", source: "gente", paint: { "circle-radius": ["get", "r"], "circle-color": ["get", "c"], "circle-opacity": ["get", "a"] } });
    m.addLayer({ id: "rastro", type: "line", source: "rastro", layout: { "line-cap": "round", "line-join": "round" }, paint: { "line-color": ["get", "c"], "line-width": 3, "line-opacity": 0.95 } });
    m.addLayer({ id: "linea-sel", type: "line", source: "linea-sel", paint: { "line-color": "#f8fafc", "line-width": 1.5, "line-dasharray": [2, 2], "line-opacity": 0.8 } });
    m.addLayer({ id: "vehiculos", type: "circle", source: "vehiculos", paint: { "circle-radius": 8, "circle-color": "#0a0c10", "circle-stroke-color": ["get", "c"], "circle-stroke-width": 2.5, "circle-opacity": ["get", "a"], "circle-stroke-opacity": ["get", "a"] } });
    m.addLayer({ id: "sel", type: "circle", source: "sel", paint: { "circle-radius": 7, "circle-color": ["get", "c"], "circle-stroke-color": "#ffffff", "circle-stroke-width": 2.5 } });
    // zona de clic amplia para cada integrante (los puntos son pequeños)
    m.addLayer({ id: "gente-hit", type: "circle", source: "gente", paint: { "circle-radius": 9, "circle-color": "#000", "circle-opacity": 0.01 } });
    m.on("click", (ev: any) => {
      const f = m.queryRenderedFeatures(ev.point, { layers: ["sel", "gente-hit"] })[0] ?? null;
      if (f?.properties?.pid) { this.onPickPersona(f.properties.grupo, f.properties.pid); return; }
      const g = m.queryRenderedFeatures(ev.point, { layers: ["vehiculos", "od", "recorrido", "pendiente"] })[0]?.properties?.grupo;
      if (g) this.onPick(g);
    });
    for (const id of ["recorrido", "pendiente", "vehiculos", "od", "gente-hit", "sel"]) {
      m.on("mouseenter", id, () => { m.getCanvas().style.cursor = "pointer"; });
      m.on("mouseleave", id, () => { m.getCanvas().style.cursor = ""; });
    }
    m.on("dragstart", () => { this.seguir = false; this.encuadre = null; });
    m.on("zoom", () => this.el.classList.toggle("acp-z6", m.getZoom() > 5.2));
    this.ready = true;
    this.loop();
  }

  escena(estados: EstadoGrupo[], puntos: Punto[]) { this.estados = estados; this.puntos = puntos; this.recorridos.clear(); this.estaticoSucio = true; }
  seleccionar(id: string | null) { if (this.sel !== id) { this.sel = id; this.estaticoSucio = true; } }
  seleccionarPersona(sel: { grupo: string; id: string } | null) {
    this.persona = sel;
    if (!sel && this.etiquetaSel) { this.etiquetaSel.remove(); this.etiquetaSel = null; }
  }
  setSeguir(v: boolean) { this.seguir = v; this.ultSeguir = 0; if (v) this.encuadre = null; }
  setEncuadre(f: (() => LngLat[]) | null) { this.encuadre = f; this.ultSeguir = 0; if (f) this.seguir = false; }

  // ------------------------------------------------------------ cámara
  general(ms = 2600) {
    this.encuadre = null; this.seguir = false;
    const pts = this.estados.flatMap((e) => [[e.g.origen.lon, e.g.origen.lat] as LngLat, [e.g.destino.lon, e.g.destino.lat] as LngLat, ...e.g.via.map((v) => [v.lon, v.lat] as LngLat)]);
    if (!pts.length) return;
    this.map.fitBounds(bbox(pts, 0.6) as LngLatBoundsLike, { padding: 40, duration: ms, easing: EASE, pitch: 0, bearing: 0, maxZoom: 7 } as any);
  }
  grupo(e: EstadoGrupo, ms = 2200) {
    this.encuadre = null; this.seguir = false;
    this.map.fitBounds(bbox(e.tr.path, 0.25) as LngLatBoundsLike, { padding: 40, duration: ms, easing: EASE, pitch: 0, bearing: 0, maxZoom: 9 } as any);
  }
  irA(p: LngLat, zoom = 13, ms = 2400) {
    this.map.flyTo({ center: p, zoom, pitch: 35, bearing: 0, duration: ms, easing: EASE } as any);
  }

  // ------------------------------------------------------------ dibujo
  private src(id: string) { return this.map.getSource(id) as GeoJSONSource | undefined; }
  private recorrido(e: EstadoGrupo): LngLat[] {
    const c = this.recorridos.get(e.g.id);
    if (c && Math.abs(c.km - e.km) < 0.15) return c.path;
    const out: LngLat[] = [];
    for (let i = 0; i < e.tr.path.length && e.tr.cum[i] < e.km; i++) out.push(e.tr.path[i]);
    out.push(sobre(e.tr, e.km));
    if (out.length < 2) out.unshift(e.tr.path[0]);
    this.recorridos.set(e.g.id, { km: e.km, path: out });
    return out;
  }
  private dim(id: string) { return this.sel && this.sel !== id ? 0.35 : 1; }

  private estatico() {
    this.estaticoSucio = false;
    const dim = (id: string) => this.dim(id);
    this.src("pendiente")?.setData(FC(this.estados.map((e) => ln(e.tr.path, { c: css(e.g.color), a: dim(e.g.id), grupo: e.g.id }))));
    this.src("od")?.setData(FC(this.estados.flatMap((e) => [
      pt([e.g.origen.lon, e.g.origen.lat], { c: css(e.g.color), o: true, a: dim(e.g.id), grupo: e.g.id }),
      pt([e.g.destino.lon, e.g.destino.lat], { c: css(e.g.color), o: false, a: dim(e.g.id), grupo: e.g.id }),
    ])));
    this.src("puntos")?.setData(FC(this.puntos.map((p) => pt([p.lon, p.lat], { c: p.tipo === "medico" ? "#38bdf8" : "#4ade80" }))));
    // etiquetas (HTML): destinos, origen del grupo seleccionado y albergues
    for (const mk of this.marcas) mk.remove();
    this.marcas = [];
    const add = (p: LngLat, txt: string, cls: string, off: [number, number]) => this.marcas.push(new maplibregl.Marker({ element: etiqueta(txt, cls), offset: off }).setLngLat(p).addTo(this.map));
    for (const e of this.estados) {
      const op = this.sel && this.sel !== e.g.id ? " acp-dim" : "";
      add([e.g.destino.lon, e.g.destino.lat], e.g.destino.nombre, "acp-lbl" + op, [0, -16]);
      if (this.sel === e.g.id) add([e.g.origen.lon, e.g.origen.lat], `Origen · ${e.g.origen.nombre}`, "acp-lbl", [0, -14]);
    }
    for (const p of this.puntos) add([p.lon, p.lat], p.nombre, "acp-lbl acp-punto", [0, 16]);
  }

  private datos(t: number, now: number) {
    const pulso = (now % 1600) / 1600;
    const rec: any[] = [], gente: any[] = [], vehs: any[] = [], anillos: any[] = [], lineas: any[] = [];
    for (const e of this.estados) {
      const a = this.dim(e.g.id), inc = e.incidente, c = css(e.g.color);
      rec.push(ln(this.recorrido(e), { c, a, grupo: e.g.id }));
      const ps = this.persona;
      for (const p of e.g.personas) {
        const pos = posPersona(e, p, t);
        const sin = ultimaSenal(e, p, t) > SIN_SENAL_S;
        const sep = !!inc?.separados.some((x) => x.id === p.id && t >= x.t0);
        const baja = bateria(e, p, t) <= BATERIA_BAJA;
        const aa = ps ? (ps.id === p.id ? 0 : 0.18) : 1;
        gente.push(pt(pos, { c: sep ? css(ROJO) : sin ? css(GRIS) : baja ? css(AMBAR) : c, a: (sin ? 0.6 : 0.9) * a * aa, r: sep ? 5 : sin || baja ? 3.2 : 2.4, grupo: e.g.id, pid: p.id }));
      }
      for (let v = 1; v <= e.g.vehiculos; v++) {
        const fuera = inc?.fuera?.vehiculo === v;
        vehs.push(pt(posVehiculo(e, v, t), { c: fuera ? css(ROJO) : c, a, grupo: e.g.id }));
      }
      if (inc && !this.persona) {
        const col = inc.alertado && !e.atendida ? ROJO : AMBAR;
        let pos: LngLat | null = null;
        const ppos = (id: string) => posPersona(e, e.g.personas.find((x) => x.id === id)!, t);
        if (inc.fuera) { pos = inc.fuera.vehiculo ? posVehiculo(e, inc.fuera.vehiculo, t) : ppos(inc.fuera.ids[0]); lineas.push(ln([inc.fuera.desde, pos], {})); }
        else if (inc.separados.length) {
          for (const s of inc.separados) if (t >= s.t0) lineas.push(ln([centro(e), ppos(s.id)], {}));
          const pr = inc.separados.find((s) => s.principal);
          if (pr && t >= pr.t0) pos = ppos(pr.id);
        } else if (Object.keys(inc.sinSenal).length) pos = Object.values(inc.sinSenal)[0].pos;
        else if (inc.tipo === "bateria") pos = centro(e);
        if (pos) for (const k of [pulso, (pulso + 0.5) % 1]) anillos.push(pt(pos, { c: css(col), r: 10 + k * 34, op: 1 - k }));
      }
      if (e.enDestino) anillos.push(pt([e.g.destino.lon, e.g.destino.lat], { c: css(VERDE), r: 10 + pulso * 34, op: 1 - pulso }));
    }
    this.src("recorrido")?.setData(FC(rec));
    this.src("gente")?.setData(FC(gente));
    this.src("vehiculos")?.setData(FC(vehs));
    this.src("anillos")?.setData(FC(anillos));
    this.src("lineas")?.setData(FC(lineas));
    // persona seleccionada: rastro, última ubicación (pulsante) y distancia al grupo
    const ps = this.persona;
    const e = ps ? this.estados.find((x) => x.g.id === ps.grupo) : undefined;
    const p = e?.g.personas.find((x) => x.id === ps!.id);
    if (e && p) {
      const f = estadoPersona(e, p, t);
      const col = f.estado === "Separado" ? ROJO : f.estado === "Sin señal" ? GRIS : f.estado === "Detenido" ? AMBAR : f.estado === "Llegó" ? VERDE : f.bat <= BATERIA_BAJA ? AMBAR : e.g.color;
      const c = centro(e);
      this.src("rastro")?.setData(FC([ln(rastro(e, p, t), { c: css(col) })]));
      this.src("sel")?.setData(FC([pt(f.pos, { c: css(col), pid: p.id, grupo: e.g.id })]));
      this.src("linea-sel")?.setData(FC(f.distGrupo > 0.03 ? [ln([c, f.pos], {})] : []));
      for (const k of [pulso, (pulso + 0.5) % 1]) anillos.push(pt(f.pos, { c: css(col), r: 9 + k * 30, op: 1 - k }));
      this.src("anillos")?.setData(FC(anillos));
      const txt = `${p.alias} · a ${kmTxt(f.distGrupo)} del grupo · ${kmTxt(f.distRuta)} de la ruta`;
      if (!this.etiquetaSel) this.etiquetaSel = new maplibregl.Marker({ element: etiqueta(txt, "acp-lbl acp-sel"), offset: [0, -22] }).setLngLat(f.pos).addTo(this.map);
      else { this.etiquetaSel.setLngLat(f.pos); this.etiquetaSel.getElement().textContent = txt; }
    } else {
      this.src("rastro")?.setData(FC([]));
      this.src("sel")?.setData(FC([]));
      this.src("linea-sel")?.setData(FC([]));
    }
  }

  private loop = () => {
    if (this.destroyed) return;
    this.raf = requestAnimationFrame(this.loop);
    if (!this.ready) return;
    const now = performance.now();
    try {
      if (this.estaticoSucio) this.estatico();
      if (now - this.ultDatos > 66) { this.ultDatos = now; this.datos(this.tiempo(), now); }
    } catch (err) { console.error(err); }
    if (this.encuadre && now - this.ultSeguir > 1000 && !this.map.isMoving()) {
      this.ultSeguir = now;
      const pts = this.encuadre();
      if (pts.length) this.map.fitBounds(bbox(pts, 0.006) as LngLatBoundsLike, { padding: 40, maxZoom: 14.5, duration: 950, easing: (x: number) => x, pitch: 30 } as any);
    } else if (this.seguir && this.sel && now - this.ultSeguir > 900 && !this.map.isMoving()) {
      this.ultSeguir = now;
      const e = this.estados.find((x) => x.g.id === this.sel);
      if (e) this.map.easeTo({ center: centro(e), duration: 850, easing: (x: number) => x } as any);
    }
  };

  destroy() { this.destroyed = true; cancelAnimationFrame(this.raf); for (const mk of this.marcas) mk.remove(); try { this.map?.remove(); } catch {} }
}
