import "./acompana.css";
import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Monitor } from "./mapa";
import Dashboard from "./Dashboard";
import { decode6, simplificar } from "@/acompana/lib/ruteo";
import { GRUPOS, PUNTOS, ESCENARIOS, type Vista, type LngLat, type EscenarioId, type Grupo, type Persona } from "@/acompana/lib/datos";
import { iniciar, avanzar, escenario, atender, estatus, estadoPersona, hhmm, hhmmDia, km, kmTxt, centro, posPersona, posVehiculo, sobre, SIM_X, BATERIA_BAJA, type EstadoGrupo, type Estatus, type FichaPersona, type EstadoP } from "@/acompana/lib/sim";

const rgb = (c: [number, number, number], a = 1) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;
const n0 = (x: number) => Math.round(x).toLocaleString("es-MX");
const COLOR_ESTATUS: Record<Estatus, string> = { "En ruta": "text-[#5eead4] bg-[#14b8a6]/12 border-[#14b8a6]/30", Detenido: "text-[#fcd34d] bg-[#f59e0b]/12 border-[#f59e0b]/35", Alerta: "text-[#fca5a5] bg-[#ef4444]/15 border-[#ef4444]/45", "En destino": "text-[#86efac] bg-[#22c55e]/12 border-[#22c55e]/35" };
const COLOR_P: Record<EstadoP, string> = { "En ruta": "text-[#5eead4] bg-[#14b8a6]/12 border-[#14b8a6]/30", Separado: "text-[#fca5a5] bg-[#ef4444]/15 border-[#ef4444]/45", "Sin señal": "text-slate-200 bg-slate-500/20 border-slate-400/35", Detenido: "text-[#fcd34d] bg-[#f59e0b]/12 border-[#f59e0b]/35", Llegó: "text-[#86efac] bg-[#22c55e]/12 border-[#22c55e]/35" };
const DOT_P: Record<EstadoP, string> = { "En ruta": "bg-[#2dd4bf]", Separado: "bg-[#ef4444]", "Sin señal": "bg-slate-500", Detenido: "bg-[#f59e0b]", Llegó: "bg-[#22c55e]" };
const NIVEL: Record<string, string> = { info: "bg-slate-500", ok: "bg-[#22c55e]", aviso: "bg-[#f59e0b]", alerta: "bg-[#ef4444]" };
const hace = (s: number) => (s < 60 ? `hace ${Math.max(1, Math.floor(s))} s` : `hace ${Math.floor(s / 60)} min`);

interface Aviso { id: number; grupo: string; titulo: string; texto: string; pos: LngLat; ok: boolean }
type Modo = "dashboard" | "monitoreo";
type PSel = { grupo: string; id: string } | null;

async function trazo(g: Grupo): Promise<LngLat[]> {
  const pts: LngLat[] = [[g.origen.lon, g.origen.lat], ...g.via.map((v) => [v.lon, v.lat] as LngLat), [g.destino.lon, g.destino.lat]];
  const c = pts.map((p) => p.map((v) => v.toFixed(4)).join(",")).join(";");
  try { const raw = localStorage.getItem(`acompana.ruta.${c}`); if (raw) return JSON.parse(raw); } catch {}
  const guardar = (x: LngLat[]) => { try { localStorage.setItem(`acompana.ruta.${c}`, JSON.stringify(x)); } catch {} return x; };
  const to = () => AbortSignal.timeout(15000);
  try {
    const body = { locations: pts.map(([lon, lat], i) => ({ lat, lon, type: i === 0 || i === pts.length - 1 ? "break" : "through", radius: 500 })), costing: "auto", directions_type: "none", units: "kilometers" };
    const j = await fetch("https://valhalla1.openstreetmap.de/route", { method: "POST", body: JSON.stringify(body), signal: to() }).then((r) => (r.ok ? r.json() : null));
    if (j?.trip) return guardar(simplificar((j.trip.legs as { shape: string }[]).flatMap((l, i) => { const d = decode6(l.shape); return i ? d.slice(1) : d; })));
  } catch {}
  try {
    const j = await fetch(`https://router.project-osrm.org/route/v1/driving/${pts.map((p) => p.join(",")).join(";")}?overview=full&geometries=geojson`, { signal: to() }).then((r) => (r.ok ? r.json() : null));
    if (j?.routes?.[0]) return guardar(simplificar(j.routes[0].geometry.coordinates));
  } catch {}
  return pts;
}

export default function Tablero({ styleUrl }: { styleUrl: string }) {
  const el = useRef<HTMLDivElement>(null);
  const mapa = useRef<Monitor | null>(null);
  const tRef = useRef(0);
  const estadosRef = useRef<Map<string, EstadoGrupo>>(new Map());
  const pendiente = useRef<string | null>(null);
  const [listo, setListo] = useState(false);
  const [modo, setModo] = useState<Modo>("dashboard");
  const [vista, setVista] = useState<Vista>("activaciones");
  const [sel, setSel] = useState<string | null>(null);
  const [psel, setPsel] = useState<PSel>(null);
  const [tab, setTab] = useState<"personas" | "linea">("personas");
  const [seguir, setSeguir] = useState(false);
  const [avisos, setAvisos] = useState<Aviso[]>([]);
  const [ultimoEsc, setUltimoEsc] = useState<Record<string, EscenarioId>>({});
  const [, setTick] = useState(0);
  const [escVer, setEscVer] = useState(0);
  const [pausa, setPausa] = useState(false);
  const avisoId = useRef(0);

  const abrirPersona = useCallback((grupo: string, id: string, centrar = true) => {
    const e = estadosRef.current.get(grupo);
    if (!e) return;
    setSel(grupo); setPsel({ grupo, id }); setTab("personas");
    const m = mapa.current;
    m?.seleccionar(grupo); m?.seleccionarPersona({ grupo, id }); m?.setEncuadre(null); m?.setSeguir(false); setSeguir(false);
    if (centrar) m?.irA(posPersona(e, e.g.personas.find((p) => p.id === id)!, tRef.current), 14, 1600);
  }, []);
  const cerrarPersona = useCallback(() => { setPsel(null); mapa.current?.seleccionarPersona(null); }, []);

  // mapa + trayectos
  useEffect(() => {
    if (!el.current) return;
    const m = new Monitor(el.current, styleUrl, () => tRef.current);
    mapa.current = m;
    if (typeof location !== "undefined" && location.search.includes("debug")) (window as unknown as { __mon: Monitor }).__mon = m;
    (async () => {
      const [, trazos] = await Promise.all([m.start(), Promise.all(GRUPOS.map(trazo))]);
      GRUPOS.forEach((g, i) => estadosRef.current.set(g.id, iniciar(g, trazos[i])));
      m.onPick = (id) => { setSel(id); m.seleccionar(id); };
      m.onPickPersona = (g, id) => abrirPersona(g, id, false);
      m.onPausa = setPausa;
      setListo(true);
    })();
    return () => m.destroy();
  }, [styleUrl, abrirPersona]);

  const estados = useMemo(() => [...estadosRef.current.values()].filter((e) => e.g.vista === vista), [vista, listo]); // eslint-disable-line react-hooks/exhaustive-deps
  const todos = useMemo(() => [...estadosRef.current.values()], [listo]); // eslint-disable-line react-hooks/exhaustive-deps

  const elegir = useCallback((id: string | null) => {
    setSel(id); setSeguir(false); setPsel(null);
    const m = mapa.current;
    m?.setSeguir(false); m?.seleccionar(id); m?.seleccionarPersona(null);
    const e = id ? estadosRef.current.get(id) : null;
    if (e) m?.grupo(e); else m?.general(2000);
  }, []);

  // escena por vista
  useEffect(() => {
    const m = mapa.current;
    if (!listo || !m?.ready) return;
    m.escena(estados, vista === "migracion" ? PUNTOS : []);
    setSeguir(false); m.setSeguir(false);
    if (pendiente.current && estadosRef.current.get(pendiente.current)?.g.vista === vista) { const id = pendiente.current; pendiente.current = null; elegir(id); }
    else { setSel(null); setPsel(null); m.seleccionar(null); m.seleccionarPersona(null); m.general(2800); }
  }, [listo, vista, estados, elegir]);

  // reloj de simulación
  useEffect(() => {
    if (!listo) return;
    let last = performance.now(), ui = 0;
    const id = setInterval(() => {
      const now = performance.now(), dt = ((now - last) / 1000) * SIM_X;
      last = now;
      tRef.current += dt;
      for (const e of estadosRef.current.values()) {
        for (const a of avanzar(e, tRef.current, dt)) setAvisos((l) => [{ id: ++avisoId.current, grupo: e.g.id, titulo: a.titulo, texto: a.texto, pos: a.pos, ok: !!a.ok }, ...l].slice(0, 3));
      }
      if (now - ui > 450) { ui = now; setTick((x) => x + 1); }
    }, 100);
    return () => clearInterval(id);
  }, [listo]);

  useEffect(() => {
    if (!avisos.length) return;
    const t = setTimeout(() => setAvisos((l) => l.slice(0, -1)), 12000);
    return () => clearTimeout(t);
  }, [avisos]);

  const monitorear = (id: string) => {
    const e = estadosRef.current.get(id);
    if (!e) return;
    setModo("monitoreo");
    if (e.g.vista !== vista) { pendiente.current = id; setVista(e.g.vista); } else elegir(id);
  };

  const grupoSel = sel ? estadosRef.current.get(sel) ?? null : null;
  const objetivo = grupoSel ?? estados[0] ?? null;

  const lanzar = (id: EscenarioId) => {
    const e = objetivo;
    if (!e) return;
    setSel(e.g.id); setPsel(null);
    const m = mapa.current;
    m?.seleccionar(e.g.id); m?.seleccionarPersona(null);
    escenario(e, id, tRef.current);
    setUltimoEsc((u) => ({ ...u, [e.g.id]: id }));
    setEscVer((v) => v + 1);
    setTab(id === "normal" ? "linea" : "personas");
    setSeguir(false); m?.setSeguir(false);
    if (!m) return;
    // cámara automática una sola vez al cambiar de escenario; después el zoom es libre
    m.setEncuadre(null);
    if (id === "normal" || id === "llegada") { m.grupo(e); return; }
    m.ajustar([centro(e), sobre(e.tr, e.km - 2), sobre(e.tr, Math.min(e.tr.total, e.km + 6))], 14);
  };

  const verAviso = (a: Aviso) => {
    const g = estadosRef.current.get(a.grupo);
    setModo("monitoreo");
    if (g && g.g.vista !== vista) { pendiente.current = a.grupo; setVista(g.g.vista); }
    setSel(a.grupo); mapa.current?.seleccionar(a.grupo); mapa.current?.irA(a.pos, 13.5, 2200);
    setAvisos((l) => l.filter((x) => x.id !== a.id));
  };

  const t = tRef.current;
  const total = estados.reduce((s, e) => s + e.g.personas.length, 0);
  const enAlerta = estados.filter((e) => estatus(e) === "Alerta").length;
  const mon = modo === "monitoreo";

  return (
    <div className="acp fixed inset-0 overflow-hidden bg-[#06080c] text-slate-200 select-none">
      <div ref={el} className="absolute inset-0" />
      <div className="fx-vignette pointer-events-none absolute inset-0" />
      {!mon && <div className="absolute inset-0 bg-[#06080c]" />}
      {!listo && <div className="absolute inset-0 grid place-items-center font-mono text-[11px] uppercase tracking-[0.3em] text-slate-500">Cargando operación…</div>}

      {/* marca */}
      <div className="glass absolute left-6 top-6 flex w-[380px] items-center gap-3 px-4 py-3">
        <svg width="30" height="30" viewBox="0 0 64 64" aria-hidden><rect width="64" height="64" rx="14" fill="#0f1a1a" /><circle cx="32" cy="32" r="15" fill="none" stroke="#2dd4bf" strokeWidth="5" /><circle cx="32" cy="32" r="5.5" fill="#2dd4bf" /><circle cx="49" cy="16" r="5" fill="#f8fafc" /></svg>
        <div className="min-w-0 flex-1">
          <div className="text-[15px] font-bold tracking-[0.18em] text-white">ACOMPAÑA</div>
          <div className="font-mono text-[10.5px] text-slate-400">Monitoreo de traslados</div>
        </div>
        <div className="text-right">
          <div className="font-mono text-[14px] font-bold tabular-nums text-white">{hhmm(t, true)}</div>
          <div className="font-mono text-[9.5px] uppercase tracking-wider text-[#5eead4]"><span className="fx-blink mr-1 inline-block h-1.5 w-1.5 rounded-full bg-[#2dd4bf] align-middle" />en vivo · demo</div>
        </div>
      </div>
      {/* navegación */}
      <div className="glass absolute left-[420px] top-6 flex h-[60px] items-center gap-1 px-2">
        {([["dashboard", "Dashboard"], ["monitoreo", "Monitoreo"]] as const).map(([v, lab]) => (
          <button key={v} onClick={() => setModo(v)} disabled={!listo} className={`rounded-lg px-4 py-2 text-[13px] font-semibold transition-colors ${modo === v ? "bg-white/10 text-white" : "text-slate-500 hover:text-slate-300"}`}>{lab}</button>
        ))}
      </div>

      {!mon && listo && <Dashboard estados={todos} t={t} onMonitorear={monitorear} />}

      {mon && (
        <aside className="fx-scroll glass absolute bottom-6 left-6 top-[98px] flex w-[380px] flex-col overflow-y-auto px-4 py-3.5">
          <div className="flex rounded-lg bg-black/30 p-0.5 text-[12.5px] font-semibold">
            {([["activaciones", "Activaciones"], ["migracion", "Migración"]] as const).map(([v, lab]) => (
              <button key={v} onClick={() => setVista(v)} className={`flex-1 rounded-md py-1.5 transition-colors ${vista === v ? "bg-white/10 text-white" : "text-slate-500 hover:text-slate-300"}`}>{lab}</button>
            ))}
          </div>
          <div className="mt-3 grid grid-cols-3 gap-2">
            <Stat k={vista === "activaciones" ? "Activaciones" : "Grupos"} v={estados.length} />
            <Stat k="Personas" v={total} />
            <Stat k="En alerta" v={enAlerta} rojo={enAlerta > 0} />
          </div>
          <div className="mt-3 flex flex-col gap-1.5">
            {estados.map((e) => {
              const st = estatus(e), on = sel === e.g.id;
              return (
                <button key={e.g.id} onClick={() => elegir(on ? null : e.g.id)} className={`rounded-xl border px-3 py-2.5 text-left transition-colors ${on ? "border-white/20 bg-white/[0.07]" : "border-white/8 bg-white/[0.02] hover:bg-white/[0.05]"}`}>
                  <div className="flex items-center gap-2">
                    <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: rgb(e.g.color) }} />
                    <span className="truncate text-[14px] font-semibold text-white">{e.g.nombre}</span>
                    <span className={`ml-auto shrink-0 rounded-full border px-2 py-0.5 font-mono text-[10px] font-bold ${COLOR_ESTATUS[st]}`}>{st}</span>
                  </div>
                  <div className="mt-1 truncate text-[12px] text-slate-400">{e.g.origen.nombre} → {e.g.destino.nombre}</div>
                  <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full" style={{ width: `${(e.km / e.tr.total) * 100}%`, background: rgb(e.g.color) }} /></div>
                  <div className="mt-1 flex justify-between font-mono text-[10.5px] text-slate-500">
                    <span>{e.g.personas.length} personas · {e.g.vehiculos ? `${e.g.vehiculos} ${e.g.vehiculos === 1 ? "vehículo" : "vehículos"}` : "a pie"}</span>
                    <span>{e.enDestino ? "llegó" : `llega ${eta(e, t)}`}</span>
                  </div>
                </button>
              );
            })}
          </div>
          <div className="mt-4 border-t border-white/8 pt-3">
            <div className="flex items-baseline justify-between">
              <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-slate-500">Escenarios</span>
              {objetivo && <span className="truncate pl-2 font-mono text-[10.5px] text-slate-400">aplica a <span className="text-white">{objetivo.g.nombre}</span></span>}
            </div>
            <div className="mt-2 grid grid-cols-2 gap-1.5">
              {ESCENARIOS.map((s) => (
                <button key={s.id} onClick={() => lanzar(s.id)} disabled={!listo}
                  className={`rounded-lg border px-2.5 py-2 text-left transition-colors disabled:opacity-40 ${objetivo && ultimoEsc[objetivo.g.id] === s.id ? "border-white/25 bg-white/[0.08]" : "border-white/8 bg-white/[0.02] hover:bg-white/[0.06]"}`}>
                  <div className="text-[12.5px] font-semibold text-white">{s.titulo}</div>
                  <div className="font-mono text-[10px] text-slate-500">{s.desc}</div>
                </button>
              ))}
            </div>
          </div>
          <div className="mt-auto pt-4 text-[11px] leading-snug text-slate-500">
            Ubicación compartida con consentimiento desde la app de registro. Se muestran nombres parciales e ID. Datos simulados para demostración.
          </div>
        </aside>
      )}

      {mon && grupoSel && (psel && psel.grupo === grupoSel.g.id
        ? <Ficha e={grupoSel} id={psel.id} t={t} onVolver={cerrarPersona} onCerrar={() => elegir(null)}
            onCentrar={(p) => mapa.current?.irA(p, 14.5, 1400)} />
        : <Detalle key={`${grupoSel.g.id}-${escVer}`} e={grupoSel} t={t} tab={tab} setTab={setTab} seguir={seguir}
            onPersona={(id) => abrirPersona(grupoSel.g.id, id)}
            onSeguir={() => { const v = !seguir; setSeguir(v); mapa.current?.setSeguir(v); if (v) mapa.current?.irA(centro(grupoSel), 12.5, 1800); }}
            onTrayecto={() => { setSeguir(false); mapa.current?.setSeguir(false); mapa.current?.grupo(grupoSel); }}
            onCerrar={() => elegir(null)} onAtender={() => { atender(grupoSel, tRef.current); setTick((x) => x + 1); }} />)}

      {/* avisos */}
      <div className="pointer-events-none absolute left-[420px] top-[96px] flex w-[400px] flex-col gap-2">
        {avisos.map((a) => (
          <button key={a.id} onClick={() => verAviso(a)} className={`fx-row pointer-events-auto rounded-xl border px-4 py-3 text-left shadow-2xl backdrop-blur ${a.ok ? "border-[#22c55e]/50 bg-[#052e16]/90" : "border-[#ef4444]/60 bg-[#2a0a0a]/92"}`}>
            <div className={`flex items-center gap-2 font-mono text-[10px] font-bold uppercase tracking-[0.2em] ${a.ok ? "text-[#86efac]" : "text-[#fca5a5]"}`}>
              <span className={`h-1.5 w-1.5 rounded-full ${a.ok ? "bg-[#22c55e]" : "fx-blink bg-[#ef4444]"}`} />{a.ok ? "Confirmación" : "Alerta"} · {hhmm(t)}
            </div>
            <div className="mt-1 text-[14px] font-semibold text-white">{a.titulo}</div>
            <div className="mt-0.5 text-[12.5px] leading-snug text-slate-300">{a.texto}</div>
            <div className="mt-1.5 font-mono text-[10.5px] text-slate-400">Ver en el mapa →</div>
          </button>
        ))}
      </div>

      {mon && (
        <div className="glass absolute bottom-6 left-[420px] flex gap-4 px-4 py-2 font-mono text-[10.5px] text-slate-300">
          <span className="flex items-center gap-1.5"><i className="inline-block h-2 w-2 rounded-full bg-[#2dd4bf]" />integrante</span>
          <span className="flex items-center gap-1.5"><i className="inline-block h-2 w-2 rounded-full bg-[#f59e0b]" />batería baja</span>
          <span className="flex items-center gap-1.5"><i className="inline-block h-2 w-2 rounded-full bg-slate-500" />sin señal</span>
          <span className="flex items-center gap-1.5"><i className="inline-block h-2 w-2 rounded-full bg-[#ef4444]" />separado</span>
          {vista === "activaciones" ? <span className="flex items-center gap-1.5"><i className="inline-block h-2.5 w-2.5 rounded-full border-2 border-[#2dd4bf] bg-black" />vehículo</span>
            : <span className="flex items-center gap-1.5"><i className="inline-block h-2.5 w-2.5 rounded-full border-2 border-[#4ade80]" />albergue</span>}
          {pausa && <span className="text-slate-400">· pausa mientras exploras</span>}
        </div>
      )}
    </div>
  );
}

function eta(e: EstadoGrupo, t: number) {
  const rest = e.tr.total - e.km;
  return hhmm(t + (rest / e.g.velKmh) * 3600);
}

function Stat({ k, v, rojo }: { k: string; v: number | string; rojo?: boolean }) {
  return (
    <div className="rounded-lg border border-white/8 bg-white/[0.02] px-2.5 py-2">
      <div className="font-mono text-[9.5px] uppercase tracking-wider text-slate-500">{k}</div>
      <div className={`font-mono text-[20px] font-bold leading-tight tabular-nums ${rojo ? "text-[#f87171]" : "text-white"}`}>{typeof v === "number" ? n0(v) : v}</div>
    </div>
  );
}

function Bateria({ v, grande }: { v: number; grande?: boolean }) {
  const c = v <= BATERIA_BAJA ? "#ef4444" : v <= 35 ? "#f59e0b" : "#4ade80";
  const w = grande ? 30 : 18, h = grande ? 14 : 9;
  return (
    <span className="inline-flex items-center gap-1.5 align-middle">
      <svg width={w + 3} height={h} viewBox={`0 0 ${w + 3} ${h}`} aria-hidden>
        <rect x="0.75" y="0.75" width={w - 1.5} height={h - 1.5} rx="2" fill="none" stroke="rgba(226,232,240,.55)" strokeWidth="1.2" />
        <rect x={w} y={h * 0.3} width="2.5" height={h * 0.4} rx="1" fill="rgba(226,232,240,.55)" />
        <rect x="2.2" y="2.2" width={Math.max(1, (w - 4.4) * (v / 100))} height={h - 4.4} rx="1" fill={c} />
      </svg>
      <span className="font-mono tabular-nums" style={{ color: c }}>{v}%</span>
    </span>
  );
}

function Avatar({ p, color, size = 56 }: { p: Persona; color: [number, number, number]; size?: number }) {
  // imagen ilustrativa: la foto real vive en la app de registro y no se muestra en el demo
  const ini = p.alias.replace(/[^A-ZÁÉÍÓÚÑ]/g, "").slice(0, 2);
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" className="shrink-0 rounded-xl" aria-label="Foto de registro">
      <rect width="64" height="64" rx="12" fill={rgb(color, 0.22)} />
      <circle cx="32" cy="25" r="11" fill={rgb(color, 0.55)} />
      <path d="M12 60c2-12 10-18 20-18s18 6 20 18z" fill={rgb(color, 0.55)} />
      <text x="58" y="60" textAnchor="end" fontSize="10" fontWeight="700" fill="#f8fafc" fontFamily="JetBrains Mono Variable, monospace">{ini}</text>
    </svg>
  );
}

const FILTROS = [["todos", "Todos"], ["alertas", "Alertas"], ["sin", "Sin señal"], ["sep", "Separados"], ["bat", "Batería baja"]] as const;
type Filtro = (typeof FILTROS)[number][0];

function Detalle({ e, t, tab, setTab, seguir, onSeguir, onTrayecto, onCerrar, onAtender, onPersona }: {
  e: EstadoGrupo; t: number; tab: "personas" | "linea"; setTab: (x: "personas" | "linea") => void; seguir: boolean;
  onSeguir: () => void; onTrayecto: () => void; onCerrar: () => void; onAtender: () => void; onPersona: (id: string) => void;
}) {
  const [q, setQ] = useState("");
  const [filtro, setFiltro] = useState<Filtro>("todos");
  const [congelada, setCongelada] = useState(false);
  const orden = useRef<string[]>([]);
  const st = estatus(e), g = e.g, inc = e.incidente;
  const crudas = g.personas.map((p) => estadoPersona(e, p, t));
  // con el puntero sobre la lista, el orden se congela para que el clic abra a la persona correcta
  let filas: FichaPersona[];
  if (congelada && orden.current.length) {
    const ix = new Map(orden.current.map((id, i) => [id, i]));
    filas = crudas.sort((a, b) => (ix.get(a.p.id) ?? 1e9) - (ix.get(b.p.id) ?? 1e9));
  } else {
    filas = crudas.sort((a, b) => rango(b) - rango(a) || a.bat - b.bat);
    orden.current = filas.map((f) => f.p.id);
  }
  const conSenal = filas.filter((f) => f.estado !== "Sin señal").length;
  const cuenta = { alertas: filas.filter((f) => f.nivel !== "ok").length, sin: filas.filter((f) => f.estado === "Sin señal").length, sep: filas.filter((f) => f.estado === "Separado").length, bat: filas.filter((f) => f.bat <= BATERIA_BAJA).length };
  const vis = filas.filter((f) => {
    const s = q.trim().toLowerCase();
    if (s && !f.p.alias.toLowerCase().includes(s) && !f.p.id.toLowerCase().includes(s)) return false;
    return filtro === "todos" || (filtro === "alertas" && f.nivel !== "ok") || (filtro === "sin" && f.estado === "Sin señal") || (filtro === "sep" && f.estado === "Separado") || (filtro === "bat" && f.bat <= BATERIA_BAJA);
  });
  const c = centro(e);
  const cercano = g.vista === "migracion" ? PUNTOS.map((x) => ({ x, d: km(c, [x.lon, x.lat]) })).sort((a, b) => a.d - b.d)[0] : null;
  const alertaTxt = inc?.alertado ? e.eventos.filter((x) => x.nivel === "alerta").slice(-1)[0]?.texto : null;

  return (
    <aside className="glass absolute bottom-6 right-6 top-6 flex w-[410px] flex-col px-4 py-4">
      <div className="flex items-start gap-2.5">
        <span className="mt-1 h-8 w-1 rounded-full" style={{ background: rgb(g.color) }} />
        <div className="min-w-0 flex-1">
          <div className="font-mono text-[10px] uppercase tracking-[0.18em] text-slate-500">{g.tipo}</div>
          <div className="text-[19px] font-bold leading-tight text-white">{g.nombre}</div>
          <div className="truncate text-[12.5px] text-slate-400">{g.origen.nombre} → {g.destino.nombre}</div>
        </div>
        <button onClick={onCerrar} className="px-1 text-[18px] leading-none text-slate-500 hover:text-white">×</button>
      </div>
      <div className="mt-3 flex items-center gap-2">
        <span className={`rounded-full border px-2.5 py-0.5 font-mono text-[11px] font-bold ${COLOR_ESTATUS[st]}`}>{st}</span>
        <span className="font-mono text-[11px] text-slate-400">{e.enDestino ? `en ${g.destino.nombre}` : `${n0(e.km)} de ${n0(e.tr.total)} km · llega ${eta(e, t)}`}</span>
      </div>
      <div className="mt-2 h-1 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full transition-all" style={{ width: `${(e.km / e.tr.total) * 100}%`, background: rgb(g.color) }} /></div>
      <div className="mt-3 grid grid-cols-3 gap-2">
        <Stat k="Personas" v={g.personas.length} />
        <Stat k={g.vehiculos ? "Vehículos" : "Traslado"} v={g.vehiculos || "A pie"} />
        <div className="rounded-lg border border-white/8 bg-white/[0.02] px-2.5 py-2">
          <div className="font-mono text-[9.5px] uppercase tracking-wider text-slate-500">Con señal</div>
          <div className={`font-mono text-[20px] font-bold leading-tight tabular-nums ${conSenal < g.personas.length ? "text-[#fcd34d]" : "text-white"}`}>{conSenal}<span className="text-[12px] text-slate-500">/{g.personas.length}</span></div>
        </div>
      </div>
      {inc?.alertado && (
        <div className={`mt-3 rounded-xl border px-3 py-2.5 ${e.atendida ? "border-[#f59e0b]/40 bg-[#f59e0b]/10" : "border-[#ef4444]/50 bg-[#ef4444]/12"}`}>
          <div className={`font-mono text-[10px] font-bold uppercase tracking-[0.18em] ${e.atendida ? "text-[#fcd34d]" : "text-[#fca5a5]"}`}>{e.atendida ? "En atención" : "Alerta activa"}</div>
          <div className="mt-0.5 text-[13px] leading-snug text-white">{alertaTxt}</div>
          {!e.atendida && <button onClick={onAtender} className="mt-2 rounded-lg border border-white/20 px-3 py-1 text-[12px] font-semibold text-white hover:bg-white/10">Marcar en atención</button>}
        </div>
      )}
      {cercano && (
        <div className="mt-3 rounded-xl border border-[#4ade80]/25 bg-[#4ade80]/[0.06] px-3 py-2 text-[12.5px]">
          <span className="text-slate-400">Punto de apoyo más cercano: </span><span className="font-semibold text-white">{cercano.x.nombre}</span><span className="text-slate-400"> · {cercano.d < 1 ? "menos de 1 km" : `${n0(cercano.d)} km`}</span>
        </div>
      )}
      <div className="mt-3 flex gap-2">
        <button onClick={onTrayecto} className="flex-1 rounded-lg border border-white/12 py-1.5 text-[12px] font-semibold text-slate-200 hover:bg-white/[0.06]">Ver trayecto</button>
        <button onClick={onSeguir} className={`flex-1 rounded-lg border py-1.5 text-[12px] font-semibold ${seguir ? "border-[#2dd4bf]/50 bg-[#2dd4bf]/10 text-[#5eead4]" : "border-white/12 text-slate-200 hover:bg-white/[0.06]"}`}>{seguir ? "Siguiendo al grupo" : "Seguir al grupo"}</button>
      </div>
      <div className="mt-3 flex gap-4 border-b border-white/8 text-[12.5px] font-semibold">
        {([["personas", "Integrantes"], ["linea", "Línea de tiempo"]] as const).map(([k, lab]) => (
          <button key={k} onClick={() => setTab(k)} className={`-mb-px border-b-2 pb-1.5 ${tab === k ? "border-white text-white" : "border-transparent text-slate-500 hover:text-slate-300"}`}>{lab}</button>
        ))}
      </div>
      {tab === "personas" ? (
        <>
          <input value={q} onChange={(x) => setQ(x.target.value)} placeholder="Buscar por nombre o ID" className="mt-2.5 rounded-lg border border-white/10 bg-black/30 px-3 py-1.5 text-[12.5px] text-white placeholder:text-slate-500 outline-none focus:border-white/25" />
          <div className="mt-2 flex flex-wrap gap-1">
            {FILTROS.map(([k, lab]) => {
              const n = k === "todos" ? g.personas.length : cuenta[k];
              return <button key={k} onClick={() => setFiltro(k)} className={`rounded-md px-2 py-0.5 font-mono text-[10.5px] ${filtro === k ? "bg-white/12 text-white" : "text-slate-500 hover:text-slate-300"}`}>{lab} {n}</button>;
            })}
          </div>
          <div onMouseEnter={() => setCongelada(true)} onMouseLeave={() => setCongelada(false)} className="fx-scroll mt-1.5 flex min-h-0 flex-1 flex-col overflow-y-auto pr-1">
            {vis.map((f) => (
              <button key={f.p.id} onClick={() => onPersona(f.p.id)} className="flex items-center gap-2.5 border-b border-white/[0.04] py-1.5 text-left hover:bg-white/[0.04]">
                <span className={`h-2 w-2 shrink-0 rounded-full ${DOT_P[f.estado]}`} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[13px] text-slate-100">{f.p.alias} <span className="font-mono text-[10.5px] text-slate-500">{f.p.id}</span></div>
                  <div className={`truncate font-mono text-[10px] ${f.nivel === "alerta" ? "text-[#fca5a5]" : f.nivel === "aviso" ? "text-[#fcd34d]" : "text-slate-500"}`}>
                    {f.estado === "Separado" ? `separado · ${kmTxt(f.distGrupo)}` : f.estado === "Sin señal" ? `sin señal ${hace(f.senal)}` : f.estado === "Detenido" ? "detenido fuera de ruta" : f.estado === "Llegó" ? "en destino" : hace(f.senal)}
                  </div>
                </div>
                <span className="text-[10.5px]"><Bateria v={f.bat} /></span>
              </button>
            ))}
            {!vis.length && <div className="py-6 text-center text-[12px] text-slate-500">Sin integrantes con este filtro</div>}
          </div>
        </>
      ) : (
        <ol className="fx-scroll mt-2 flex min-h-0 flex-1 flex-col overflow-y-auto pr-1">
          {[...e.eventos].reverse().map((ev, i) => (
            <li key={i} className="flex gap-2.5 py-1.5">
              <span className="w-[74px] shrink-0 font-mono text-[11px] text-slate-400">{hhmmDia(ev.t)}</span>
              <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${NIVEL[ev.nivel]}`} />
              <span className={`text-[12.5px] leading-snug ${ev.nivel === "alerta" ? "text-[#fecaca]" : "text-slate-200"}`}>{ev.texto}</span>
            </li>
          ))}
        </ol>
      )}
    </aside>
  );
}
const rango = (f: FichaPersona) => (f.nivel === "alerta" ? 3 : f.nivel === "aviso" ? 2 : 0) + (f.estado === "Separado" ? 0.5 : 0);

function Ficha({ e, id, t, onVolver, onCerrar, onCentrar }: { e: EstadoGrupo; id: string; t: number; onVolver: () => void; onCerrar: () => void; onCentrar: (p: LngLat) => void }) {
  const p = e.g.personas.find((x) => x.id === id);
  if (!p) return null;
  const f = estadoPersona(e, p, t);
  const g = e.g;
  const fila = (k: string, v: ReactNode) => (
    <div className="flex items-baseline justify-between gap-3 border-b border-white/[0.05] py-[7px]">
      <span className="shrink-0 font-mono text-[10px] uppercase tracking-wider text-slate-500">{k}</span>
      <span className="text-right text-[12.5px] text-slate-100">{v}</span>
    </div>
  );
  const tono = f.nivel === "alerta" ? "border-[#ef4444]/50 bg-[#ef4444]/12 text-[#fecaca]" : f.nivel === "aviso" ? "border-[#f59e0b]/40 bg-[#f59e0b]/10 text-[#fde68a]" : "border-[#22c55e]/30 bg-[#22c55e]/[0.07] text-[#bbf7d0]";
  return (
    <aside className="fx-scroll glass absolute bottom-6 right-6 top-6 flex w-[410px] flex-col overflow-y-auto px-4 py-4">
      <div className="flex items-center justify-between">
        <button onClick={onVolver} className="font-mono text-[11px] text-slate-400 hover:text-white">← Integrantes de {g.nombre}</button>
        <button onClick={onCerrar} className="px-1 text-[18px] leading-none text-slate-500 hover:text-white">×</button>
      </div>
      <div className="mt-3 flex items-center gap-3.5">
        <Avatar p={p} color={g.color} />
        <div className="min-w-0 flex-1">
          <div className="text-[20px] font-bold leading-tight text-white">{p.alias}</div>
          <div className="font-mono text-[11px] text-slate-400">{p.id}</div>
          <span className={`mt-1 inline-block rounded-full border px-2.5 py-0.5 font-mono text-[10.5px] font-bold ${COLOR_P[f.estado]}`}>{f.estado}</span>
        </div>
        <div className="text-right text-[13px]"><Bateria v={f.bat} grande /></div>
      </div>
      <div className={`mt-3 rounded-xl border px-3 py-2.5 ${tono}`}>
        <div className="font-mono text-[9.5px] font-bold uppercase tracking-[0.18em] opacity-80">Causa probable</div>
        <div className="mt-0.5 text-[13.5px] font-semibold leading-snug">{f.causa}</div>
      </div>
      <div className="mt-2">
        {fila("Grupo", <>{g.nombre}{g.vehiculos ? <span className="text-slate-400"> · vehículo {p.vehiculo}</span> : <span className="text-slate-400"> · a pie</span>}</>)}
        {fila("Identificación", <>{p.doc} <span className="font-mono text-slate-400">•••• {p.doc4}</span></>)}
        {fila("Contacto de emergencia", <>{p.contacto.rel} <span className="font-mono text-slate-400">•• •••• {p.contacto.tel4}</span></>)}
        {fila("Batería", <Bateria v={f.bat} />)}
        {fila("Última señal", <><span className="font-mono">{hhmm(t - f.senal, true)}</span> <span className={f.senal > 120 ? "text-[#fcd34d]" : "text-slate-400"}>· {hace(f.senal)}</span></>)}
        {fila("Coordenadas", <span className="font-mono">{f.pos[1].toFixed(5)}, {f.pos[0].toFixed(5)}</span>)}
        {fila("Velocidad", <span className="font-mono">{f.estado === "Sin señal" ? "sin dato" : `${f.velKmh} km/h`}</span>)}
        {fila("Precisión GPS", <span className="font-mono">± {f.precisionM} m</span>)}
        {fila("Distancia", <><span className={f.distGrupo > 0.5 ? "text-[#fca5a5]" : ""}>{kmTxt(f.distGrupo)} del grupo</span><span className="text-slate-400"> · {kmTxt(f.distRuta)} de la ruta</span></>)}
      </div>
      <div className="mt-3 flex gap-2">
        <button onClick={() => onCentrar(f.pos)} className="flex-1 rounded-lg border border-white/12 py-1.5 text-[12px] font-semibold text-slate-200 hover:bg-white/[0.06]">Centrar en el mapa</button>
        <button onClick={onVolver} className="flex-1 rounded-lg border border-white/12 py-1.5 text-[12px] font-semibold text-slate-200 hover:bg-white/[0.06]">Ver grupo</button>
      </div>
      <div className="mt-auto pt-4 text-[10.5px] leading-snug text-slate-500">Datos compartidos con consentimiento desde la app. Identificación y teléfono enmascarados; imagen ilustrativa.</div>
    </aside>
  );
}
