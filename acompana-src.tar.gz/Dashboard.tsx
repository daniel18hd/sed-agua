import { useMemo, useState } from "react";
import type { Vista } from "@/acompana/lib/datos";
import { estatus, hhmm, ultimaSenal, bateria, SIN_SENAL_S, BATERIA_BAJA, HORA_BASE, type EstadoGrupo, type Estatus } from "@/acompana/lib/sim";

const rgb = (c: [number, number, number], a = 1) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;
const n0 = (x: number) => Math.round(x).toLocaleString("es-MX");
const CHIP: Record<Estatus, string> = { "En ruta": "text-[#5eead4] bg-[#14b8a6]/12 border-[#14b8a6]/30", Detenido: "text-[#fcd34d] bg-[#f59e0b]/12 border-[#f59e0b]/35", Alerta: "text-[#fca5a5] bg-[#ef4444]/15 border-[#ef4444]/45", "En destino": "text-[#86efac] bg-[#22c55e]/12 border-[#22c55e]/35" };

export interface Resumen { personas: number; sinSenal: number; bateriaBaja: number; separados: number; llegaron: number; enRuta: number; bats: number[] }
export function resumenGrupo(e: EstadoGrupo, t: number): Resumen {
  let sinSenal = 0, bateriaBaja = 0, separados = 0;
  const bats: number[] = [];
  const inc = e.incidente;
  for (const p of e.g.personas) {
    const s = ultimaSenal(e, p, t), b = bateria(e, p, t);
    bats.push(b);
    const sin = s > SIN_SENAL_S;
    if (sin) sinSenal++;
    else if (inc?.separados.some((x) => x.id === p.id && t >= x.t0)) separados++;
    if (b <= BATERIA_BAJA) bateriaBaja++;
  }
  const n = e.g.personas.length;
  const llegaron = e.enDestino ? n - sinSenal - separados : 0;
  return { personas: n, sinSenal, bateriaBaja, separados, llegaron, enRuta: e.enDestino ? 0 : n - sinSenal - separados, bats };
}

// alertas atendidas en horas previas (historial simulado para la gráfica y la bitácora)
const HISTORIAL = [
  { h: -11, grupo: "M21", texto: "Pérdida de señal · 3 integrantes" }, { h: -9, grupo: "BP", texto: "Integrante rezagado en parada" },
  { h: -8, grupo: "M21", texto: "Batería baja · 5 equipos" }, { h: -7, grupo: "BN", texto: "Pérdida de señal · tramo sin cobertura" },
  { h: -6, grupo: "M15", texto: "Detención no programada · 14 min" }, { h: -5, grupo: "BS", texto: "Integrante separado · 600 m" },
  { h: -4, grupo: "M08", texto: "Pérdida de señal · 2 integrantes" }, { h: -3, grupo: "BG", texto: "Batería baja · 4 equipos" },
  { h: -3, grupo: "BN", texto: "Integrante rezagado en caseta" }, { h: -2, grupo: "M21", texto: "Integrante separado · 900 m" },
  { h: -1, grupo: "BS", texto: "Detención no programada · 9 min" }, { h: -1, grupo: "BP", texto: "Batería baja · 3 equipos" },
];

export default function Dashboard({ estados, t, onMonitorear }: { estados: EstadoGrupo[]; t: number; onMonitorear: (id: string) => void }) {
  const [alcance, setAlcance] = useState<"todo" | Vista>("todo");
  const gs = estados.filter((e) => alcance === "todo" || e.g.vista === alcance);
  const res = gs.map((e) => ({ e, r: resumenGrupo(e, t), st: estatus(e) }));
  const sum = (k: keyof Omit<Resumen, "bats">) => res.reduce((s, x) => s + x.r[k], 0);
  const alertasActivas = res.filter((x) => x.st === "Alerta").length;
  const horaAhora = Math.floor((HORA_BASE + t) / 3600);

  // alertas por hora (12 h)
  const porHora = useMemo(() => {
    const b = Array.from({ length: 12 }, (_, i) => ({ h: horaAhora - 11 + i, n: 0 }));
    for (const a of HISTORIAL) if (gs.some((e) => e.g.id === a.grupo)) { const x = b.find((y) => y.h === horaAhora + a.h); if (x) x.n++; }
    for (const e of gs) for (const ev of e.eventos) if (ev.nivel === "alerta") { const x = b.find((y) => y.h === Math.floor((HORA_BASE + ev.t) / 3600)); if (x) x.n++; }
    return b;
  }, [gs.map((e) => e.g.id + e.eventos.length).join(), horaAhora]); // eslint-disable-line react-hooks/exhaustive-deps
  const maxH = Math.max(3, ...porHora.map((x) => x.n));

  // distribución de batería
  const buckets = Array.from({ length: 10 }, () => 0);
  for (const x of res) for (const b of x.r.bats) buckets[Math.min(9, Math.floor(b / 10))]++;
  const maxB = Math.max(1, ...buckets);

  const recientes = [
    ...gs.flatMap((e) => e.eventos.filter((ev) => ev.nivel === "alerta").map((ev) => ({ t: ev.t, e, texto: ev.texto, activa: estatus(e) === "Alerta" || (e.incidente?.alertado && !e.atendida) }))),
    ...HISTORIAL.filter((a) => gs.some((e) => e.g.id === a.grupo)).map((a, i) => ({ t: (horaAhora + a.h) * 3600 - HORA_BASE + ((i * 997) % 3000), e: gs.find((e) => e.g.id === a.grupo)!, texto: a.texto, activa: false })),
  ].sort((a, b) => b.t - a.t).slice(0, 9);

  const kpis: [string, number, string?][] = [
    ["Personas activas", sum("personas")], ["Grupos", gs.length], ["Grupos en ruta", res.filter((x) => x.st === "En ruta" || x.st === "Detenido").length],
    ["Alertas activas", alertasActivas, alertasActivas ? "rojo" : undefined], ["Sin señal", sum("sinSenal"), sum("sinSenal") ? "gris" : undefined],
    ["Batería baja", sum("bateriaBaja"), "ambar"], ["Llegadas", res.filter((x) => x.e.enDestino).length, "verde"],
  ];

  return (
    <div className="fx-scroll absolute bottom-6 left-6 right-6 top-[112px] overflow-y-auto pr-1">
      <div className="mb-3 flex items-end justify-between">
        <div>
          <div className="font-mono text-[10.5px] uppercase tracking-[0.2em] text-slate-500">Panorama de la operación · {hhmm(t)}</div>
          <div className="text-[22px] font-bold text-white">Dashboard general</div>
        </div>
        <div className="flex rounded-lg bg-black/30 p-0.5 text-[12px] font-semibold">
          {([["todo", "Todo"], ["activaciones", "Activaciones"], ["migracion", "Migración"]] as const).map(([v, lab]) => (
            <button key={v} onClick={() => setAlcance(v)} className={`rounded-md px-3 py-1.5 ${alcance === v ? "bg-white/10 text-white" : "text-slate-500 hover:text-slate-300"}`}>{lab}</button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-7 gap-2.5">
        {kpis.map(([k, v, tono]) => (
          <div key={k} className="glass px-3.5 py-3">
            <div className="font-mono text-[9.5px] uppercase tracking-wider text-slate-500">{k}</div>
            <div className={`mt-0.5 font-mono text-[26px] font-bold tabular-nums ${tono === "rojo" ? "text-[#f87171]" : tono === "ambar" && v ? "text-[#fbbf24]" : tono === "verde" && v ? "text-[#4ade80]" : tono === "gris" ? "text-slate-300" : "text-white"}`}>{n0(v)}</div>
          </div>
        ))}
      </div>

      <div className="mt-2.5 grid grid-cols-3 gap-2.5">
        <div className="glass px-4 py-3.5">
          <div className="text-[13px] font-semibold text-white">Alertas por hora</div>
          <div className="font-mono text-[10px] text-slate-500">últimas 12 horas</div>
          <div className="mt-3 flex h-[120px] items-end gap-1.5">
            {porHora.map((x) => (
              <div key={x.h} className="flex flex-1 flex-col items-center gap-1">
                <span className="font-mono text-[9.5px] text-slate-400">{x.n || ""}</span>
                <div className={`w-full rounded-t ${x.h === horaAhora ? "bg-[#ef4444]/80" : "bg-[#2dd4bf]/55"}`} style={{ height: `${(x.n / maxH) * 92 + 2}px` }} />
              </div>
            ))}
          </div>
          <div className="mt-1 flex gap-1.5">{porHora.map((x) => <span key={x.h} className="flex-1 text-center font-mono text-[9px] text-slate-500">{String(((x.h % 24) + 24) % 24).padStart(2, "0")}</span>)}</div>
        </div>
        <div className="glass px-4 py-3.5">
          <div className="text-[13px] font-semibold text-white">Distribución de batería</div>
          <div className="font-mono text-[10px] text-slate-500">{n0(sum("personas"))} equipos · % de carga</div>
          <div className="mt-3 flex h-[120px] items-end gap-1.5">
            {buckets.map((n, i) => (
              <div key={i} className="flex flex-1 flex-col items-center gap-1">
                <span className="font-mono text-[9.5px] text-slate-400">{n || ""}</span>
                <div className="w-full rounded-t" style={{ height: `${(n / maxB) * 92 + 2}px`, background: i < 2 ? "rgba(239,68,68,.75)" : i < 4 ? "rgba(245,158,11,.7)" : "rgba(74,222,128,.55)" }} />
              </div>
            ))}
          </div>
          <div className="mt-1 flex gap-1.5">{buckets.map((_, i) => <span key={i} className="flex-1 text-center font-mono text-[9px] text-slate-500">{i * 10}</span>)}</div>
        </div>
        <div className="glass px-4 py-3.5">
          <div className="text-[13px] font-semibold text-white">Estado por grupo</div>
          <div className="flex gap-3 font-mono text-[10px] text-slate-500">
            <span><i className="mr-1 inline-block h-2 w-2 rounded-sm bg-[#2dd4bf]" />en ruta</span><span><i className="mr-1 inline-block h-2 w-2 rounded-sm bg-[#22c55e]" />llegó</span>
            <span><i className="mr-1 inline-block h-2 w-2 rounded-sm bg-slate-500" />sin señal</span><span><i className="mr-1 inline-block h-2 w-2 rounded-sm bg-[#ef4444]" />separado</span>
          </div>
          <div className="mt-2.5 flex flex-col gap-2">
            {res.map(({ e, r }) => (
              <div key={e.g.id} className="flex items-center gap-2">
                <span className="w-[104px] truncate text-[12px] text-slate-300">{e.g.nombre}</span>
                <div className="flex h-2.5 flex-1 overflow-hidden rounded-full bg-white/5">
                  <div style={{ width: `${(r.enRuta / r.personas) * 100}%` }} className="bg-[#2dd4bf]/80" />
                  <div style={{ width: `${(r.llegaron / r.personas) * 100}%` }} className="bg-[#22c55e]/80" />
                  <div style={{ width: `${(r.sinSenal / r.personas) * 100}%` }} className="bg-slate-500" />
                  <div style={{ width: `${(r.separados / r.personas) * 100}%` }} className="bg-[#ef4444]" />
                </div>
                <span className="w-[54px] text-right font-mono text-[10px] text-slate-500">{r.bateriaBaja ? `${r.bateriaBaja} bat.` : ""}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-2.5 grid grid-cols-3 gap-2.5">
        <div className="glass col-span-2 px-4 py-3.5">
          <div className="text-[13px] font-semibold text-white">Grupos en seguimiento</div>
          <table className="mt-2 w-full text-left text-[12.5px]">
            <thead className="font-mono text-[9.5px] uppercase tracking-wider text-slate-500">
              <tr><th className="py-1.5 font-normal">Grupo</th><th className="font-normal">Trayecto</th><th className="font-normal">Personas</th><th className="font-normal">Estado</th><th className="font-normal">Avance</th><th className="font-normal">Sin señal</th><th className="font-normal">Bat. baja</th><th /></tr>
            </thead>
            <tbody>
              {res.map(({ e, r, st }) => (
                <tr key={e.g.id} className="border-t border-white/[0.06]">
                  <td className="py-2"><span className="mr-2 inline-block h-2 w-2 rounded-full" style={{ background: rgb(e.g.color) }} /><span className="font-semibold text-white">{e.g.nombre}</span><div className="pl-4 font-mono text-[10px] text-slate-500">{e.g.tipo}</div></td>
                  <td className="text-slate-400">{e.g.origen.nombre.split(",")[0]} → {e.g.destino.nombre.split(",")[0]}</td>
                  <td className="font-mono text-slate-300">{e.g.personas.length}<span className="text-slate-500"> · {e.g.vehiculos ? `${e.g.vehiculos} veh` : "a pie"}</span></td>
                  <td><span className={`rounded-full border px-2 py-0.5 font-mono text-[10px] font-bold ${CHIP[st]}`}>{st}</span></td>
                  <td className="w-[120px] pr-3"><div className="h-1 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full" style={{ width: `${(e.km / e.tr.total) * 100}%`, background: rgb(e.g.color) }} /></div></td>
                  <td className={`font-mono ${r.sinSenal ? "text-slate-200" : "text-slate-500"}`}>{r.sinSenal}</td>
                  <td className={`font-mono ${r.bateriaBaja ? "text-[#fbbf24]" : "text-slate-500"}`}>{r.bateriaBaja}</td>
                  <td className="text-right"><button onClick={() => onMonitorear(e.g.id)} className="rounded-lg border border-white/12 px-2.5 py-1 text-[11.5px] font-semibold text-slate-200 hover:bg-white/[0.07]">Monitorear →</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="glass px-4 py-3.5">
          <div className="text-[13px] font-semibold text-white">Alertas recientes</div>
          <div className="mt-2 flex flex-col">
            {recientes.map((a, i) => (
              <button key={i} onClick={() => onMonitorear(a.e.g.id)} className="flex gap-2.5 border-t border-white/[0.06] py-2 text-left hover:bg-white/[0.03]">
                <span className="w-10 shrink-0 font-mono text-[11px] text-slate-400">{hhmm(a.t)}</span>
                <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${a.activa ? "fx-blink bg-[#ef4444]" : "bg-slate-600"}`} />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[12.5px] text-slate-200">{a.texto}</span>
                  <span className="font-mono text-[10px] text-slate-500">{a.e.g.nombre} · {a.activa ? "activa" : "atendida"}</span>
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
